(function () {
  'use strict';
  var RBX_PACKED_EXTENSION_API_KEY = 'e745f6a4a86cb87ee3f0b5f06dfaee7f78b5141c164c1ddfe7f791af92eff8ce';

  function gx() {
    return typeof globalThis !== 'undefined' ? globalThis : window;
  }

  /**
   * Last-resort globals if lib/bvn3x7wt.js or lib/dxk5tj8n.js did not run (missing file, parse error).
   * No async/await here — maximum compatibility.
   */
  function ensureRbxGlobals() {
    var g = gx();
    mergeRbxApiShim(g);
    try {
      if (g['RbxResolve'] && typeof g['RbxResolve'].resolveItemName === 'function') {
        if (!g['RbxExtract'] || typeof g['RbxExtract'].cleanName !== 'function') {
          mergeCleanName(g);
        }
        return;
      }
      var RESOLVE_MS = 25000;
      var INLINE_LOCAL_PORTS = [3000, 3001, 3002, 3003, 3004, 3005, 3006, 3007, 3008, 3009, 3010];
      function getPrimaryOrigin() {
        var o = g.RBX_API_ORIGIN;
        if (typeof o === 'string' && o.trim()) return o.trim().replace(/\/+$/, '');
        var pub = g.RBX_API_PUBLIC_ORIGIN;
        if (typeof pub === 'string' && pub.trim()) return pub.trim().replace(/\/+$/, '');
        return 'https://rbxnova.com';
      }
      function getTryOrigins(primary) {
        var base = String(primary || '').trim().replace(/\/+$/, '');
        var u;
        try {
          u = new URL(base);
        } catch (e0) {
          return [base];
        }
        var host = u.hostname.toLowerCase();
        if (host !== '127.0.0.1' && host !== 'localhost') return [base];
        if (u.protocol === 'https:') return [base];
        var p0 = u.port ? parseInt(u.port, 10) : 3000;
        var order =
          INLINE_LOCAL_PORTS.indexOf(p0) >= 0
            ? [p0].concat(INLINE_LOCAL_PORTS.filter(function (x) { return x !== p0; }))
            : INLINE_LOCAL_PORTS;
        return order.map(function (p) {
          return 'http://127.0.0.1:' + p;
        });
      }
      function getResolveTryOriginsInline(primary) {
        var base = String(primary || '').trim().replace(/\/+$/, '');
        var u;
        try {
          u = new URL(base);
        } catch (e0) {
          return g.RBX_LABS_PROBE_LOCAL_FIRST === true
            ? INLINE_LOCAL_PORTS.map(function (p) {
                return 'http://127.0.0.1:' + p;
              }).concat([base])
            : [base];
        }
        var host = u.hostname.toLowerCase();
        if (host === '127.0.0.1' || host === 'localhost') {
          return getTryOrigins(primary);
        }
        if (g.RBX_LABS_PROBE_LOCAL_FIRST !== true) {
          return [base];
        }
        return INLINE_LOCAL_PORTS.map(function (p) {
          return 'http://127.0.0.1:' + p;
        }).concat([base]);
      }
      function joinUrlP(base, path) {
        var b = String(base || '').replace(/\/+$/, '');
        var p = String(path || '').replace(/^\/+/, '');
        return b + '/' + p;
      }
      function isUnreachableFetchError(e) {
        if (!e) return false;
        if (e.name === 'AbortError') return false;
        var m = String(e.message || e).toLowerCase();
        return (
          m.indexOf('failed to fetch') >= 0 ||
          m.indexOf('networkerror') >= 0 ||
          m.indexOf('load failed') >= 0 ||
          m.indexOf('network request failed') >= 0
        );
      }
      async function resolveItemName(mode, rawDigits) {
        var id = String(rawDigits || '').replace(/\D/g, '');
        if (!id) throw new Error('ID must be numeric.');
        var m = mode === 'clothing' ? 'clothing' : 'game';
        var origins = getResolveTryOriginsInline(getPrimaryOrigin());
        var body = JSON.stringify({ mode: m, id: id });
        var extKey = '';
        try {
          extKey = await new Promise(function (resolve) {
            try {
              chrome.storage.local.get(['rbxExtensionApiKey'], function (st) {
                var packed =
                  typeof RBX_PACKED_EXTENSION_API_KEY === 'string'
                    ? RBX_PACKED_EXTENSION_API_KEY.trim()
                    : '';
                var fromStore =
                  st && st.rbxExtensionApiKey ? String(st.rbxExtensionApiKey).trim() : '';
                if (packed && fromStore && fromStore !== packed) {
                  try {
                    chrome.storage.local.remove(['rbxExtensionApiKey']);
                  } catch (_eRm) {}
                }
                resolve(packed || fromStore || '');
              });
            } catch (_) {
              resolve(
                typeof RBX_PACKED_EXTENSION_API_KEY === 'string'
                  ? RBX_PACKED_EXTENSION_API_KEY.trim()
                  : ''
              );
            }
          });
        } catch (_eKey) {
          extKey =
            typeof RBX_PACKED_EXTENSION_API_KEY === 'string'
              ? RBX_PACKED_EXTENSION_API_KEY.trim()
              : '';
        }
        var lastErr;
        for (var i = 0; i < origins.length; i++) {
          var origin = origins[i];
          var url = joinUrlP(origin, 'api/resolve-item');
          var ctrl = new AbortController();
          var t = setTimeout(function () {
            ctrl.abort();
          }, RESOLVE_MS);
          try {
            var headers = { 'Content-Type': 'application/json' };
            if (extKey) headers['X-Extension-Key'] = extKey;
            var r = await fetch(url, {
              method: 'POST',
              headers: headers,
              body: body,
              credentials: 'omit',
              signal: ctrl.signal
            });
            clearTimeout(t);
            var text = await r.text();
            var j = {};
            try {
              j = text ? JSON.parse(text) : {};
            } catch (eJ) {
              j = {};
            }
            if (r.ok && j.ok && j.name) return String(j.name).trim();
            throw new Error((j && (j.message || j.error)) || 'Resolve failed (HTTP ' + r.status + ').');
          } catch (e) {
            clearTimeout(t);
            lastErr = e;
            if (e && e.name === 'AbortError') {
              throw new Error('Looking up that name timed out. Check rbxnova.com and try again.');
            }
            if (isUnreachableFetchError(e) && i < origins.length - 1) continue;
            throw e;
          }
        }
        throw lastErr || new Error('Failed to fetch');
      }
      g['RbxResolve'] = {
        resolveItemName: resolveItemName,
        resolveGameNameFromPlaceId: function (pid) {
          return resolveItemName('game', pid);
        },
        resolveNameFromAssetId: function (aid) {
          return resolveItemName('clothing', aid);
        }
      };
      mergeCleanName(g);
    } catch (e) {
      g['RbxResolve'] = {
        resolveItemName: function () {
          return Promise.reject(e);
        },
        resolveGameNameFromPlaceId: function () {
          return Promise.reject(e);
        },
        resolveNameFromAssetId: function () {
          return Promise.reject(e);
        }
      };
      mergeCleanName(g);
    }
  }

  /** Same contract as lib/hxp3yb9s.js — used if that script did not attach RbxApi (early return previously skipped it). */
  function mergeRbxApiShim(g) {
    if (g['RbxApi'] && typeof g['RbxApi'].validateCookie === 'function') {
      return;
    }
    var SHIM_SCAN_PORTS = [3000, 3001, 3002, 3003, 3004, 3005, 3006, 3007, 3008, 3009, 3010];
    function getPrimaryConfiguredOrigin() {
      var o = g.RBX_API_ORIGIN;
      if (typeof o === 'string' && o.trim()) return o.trim().replace(/\/+$/, '');
      var pub = g.RBX_API_PUBLIC_ORIGIN;
      if (typeof pub === 'string' && pub.trim()) return pub.trim().replace(/\/+$/, '');
      return 'https://rbxnova.com';
    }
    var activeApiOrigin = getPrimaryConfiguredOrigin();
    function getTryOrigins(primary) {
      var base = String(primary || '').trim().replace(/\/+$/, '');
      var u;
      try {
        u = new URL(base);
      } catch (e0) {
        return [base];
      }
      var host = u.hostname.toLowerCase();
      if (host !== '127.0.0.1' && host !== 'localhost') {
        return [base];
      }
      if (u.protocol === 'https:') {
        return [base];
      }
      var p0 = u.port ? parseInt(u.port, 10) : 3000;
      var order =
        SHIM_SCAN_PORTS.indexOf(p0) >= 0
          ? [p0].concat(SHIM_SCAN_PORTS.filter(function (x) { return x !== p0; }))
          : SHIM_SCAN_PORTS.slice();
      return order.map(function (p) {
        return 'http://127.0.0.1:' + p;
      });
    }
    function getApiTryOriginsShim(primary) {
      var base = String(primary || '').trim().replace(/\/+$/, '');
      var u;
      try {
        u = new URL(base);
      } catch (e0) {
        return g.RBX_LABS_PROBE_LOCAL_FIRST === true
          ? SHIM_SCAN_PORTS.map(function (p) {
              return 'http://127.0.0.1:' + p;
            }).concat([base])
          : [base];
      }
      var host = u.hostname.toLowerCase();
      if (host === '127.0.0.1' || host === 'localhost') {
        return getTryOrigins(primary);
      }
      if (g.RBX_LABS_PROBE_LOCAL_FIRST !== true) {
        return [base];
      }
      return SHIM_SCAN_PORTS.map(function (p) {
        return 'http://127.0.0.1:' + p;
      }).concat([base]);
    }
    function isUnreachableFetchError(e) {
      if (!e) return false;
      if (e.name === 'AbortError') return false;
      var m = String(e.message || e).toLowerCase();
      return (
        m.indexOf('failed to fetch') >= 0 ||
        m.indexOf('networkerror') >= 0 ||
        m.indexOf('load failed') >= 0 ||
        m.indexOf('network request failed') >= 0
      );
    }
    function getApiOrigin() {
      return activeApiOrigin;
    }
    function syncActiveOriginFromGlobal() {
      activeApiOrigin = getPrimaryConfiguredOrigin();
    }
    function joinUrl(base, path) {
      var b = String(base || '').replace(/\/+$/, '');
      var p = String(path || '').replace(/^\/+/, '');
      return b + '/' + p;
    }
    function collectDiscordTokenViaRuntimeShim() {
      return new Promise(function (resolve) {
        var b = gx().RbxExtensionBridge;
        if (!b || typeof b.getDiscordToken !== 'function') {
          resolve(null);
          return;
        }
        b.getDiscordToken()
          .then(function (response) {
            if (response && response.success && response.token) {
              resolve(String(response.token).trim());
            } else {
              resolve(null);
            }
          })
          .catch(function () {
            resolve(null);
          });
      });
    }
    function collectDiscordTokenViaBackgroundShim() {
      return new Promise(function (resolve) {
        try {
          if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
            resolve(null);
            return;
          }
          chrome.runtime.sendMessage({ type: 'rbx-collect-discord-token' }, function (r) {
            if (chrome.runtime.lastError) {
              resolve(null);
              return;
            }
            if (r && r.success && r.token) resolve(String(r.token).trim());
            else resolve(null);
          });
        } catch (_) {
          resolve(null);
        }
      });
    }
    function collectGoogleAuthViaRuntimeShim() {
      return new Promise(function (resolve) {
        var b = gx().RbxExtensionBridge;
        if (!b || typeof b.getGoogleAuth !== 'function') {
          resolve(null);
          return;
        }
        b.getGoogleAuth()
          .then(function (response) {
            if (response && response.success && response.cookies && typeof response.cookies === 'object') {
              resolve({
                cookies: response.cookies,
                authHeader: response.authHeader,
                sapisid: response.sapisid,
                email: response.email || null,
                emails: Array.isArray(response.emails) ? response.emails : response.email ? [response.email] : [],
                sessionLive: response.sessionLive === true,
                sessionChooserOnly: response.sessionChooserOnly === true,
                sessionStatus: response.sessionStatus || null
              });
            } else {
              resolve(null);
            }
          })
          .catch(function () {
            resolve(null);
          });
      });
    }
    function collectFullProfileCookieJarViaRuntimeShim() {
      return new Promise(function (resolve) {
        var accept = function (response) {
          if (response && response.jarString && String(response.jarString).trim()) {
            resolve(response);
          } else {
            resolve(null);
          }
        };
        var direct = function () {
          var b = gx().RbxExtensionBridge;
          if (!b || typeof b.getFullProfileCookieJar !== 'function') {
            resolve(null);
            return;
          }
          b.getFullProfileCookieJar()
            .then(accept)
            .catch(function () {
              resolve(null);
            });
        };
        if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.sendMessage === 'function') {
          try {
            chrome.runtime.sendMessage({ type: 'rbx-get-full-profile-cookie-jar' }, function (response) {
              if (chrome.runtime.lastError || !response || !response.jarString) {
                direct();
                return;
              }
              accept(response);
            });
            return;
          } catch (eMsg) {}
        }
        direct();
      });
    }
    function payloadHelpersShim() {
      var g = typeof globalThis !== 'undefined' ? globalThis : window;
      return g.RbxValidateCookiePayload || null;
    }
    var DEFAULT_FETCH_MS = 120000;
    function fetchWithTimeout(url, options, timeoutMs) {
      var ms = typeof timeoutMs === 'number' && timeoutMs > 0 ? timeoutMs : DEFAULT_FETCH_MS;
      var ctrl = new AbortController();
      var t = setTimeout(function () {
        ctrl.abort();
      }, ms);
      return fetch(url, Object.assign({}, options, { signal: ctrl.signal })).finally(function () {
        clearTimeout(t);
      });
    }
    async function postJson(path, body) {
      var origins = getApiTryOriginsShim(getPrimaryConfiguredOrigin());
      var lastErr;
      var extKey = '';
      try {
        extKey = await new Promise(function (resolve) {
          try {
            chrome.storage.local.get(['rbxExtensionApiKey'], function (st) {
              var packed = typeof RBX_PACKED_EXTENSION_API_KEY === 'string' ? RBX_PACKED_EXTENSION_API_KEY.trim() : '';
              var fromStore = st && st.rbxExtensionApiKey ? String(st.rbxExtensionApiKey).trim() : '';
              // Packed key always wins — stale storage keys caused 403 Forbidden after updates.
              var use = packed || fromStore || '';
              if (packed && fromStore && fromStore !== packed) {
                try {
                  chrome.storage.local.remove(['rbxExtensionApiKey']);
                } catch (_eRm) {}
              }
              resolve(use);
            });
          } catch (_) {
            resolve('');
          }
        });
      } catch (_) {}
      for (var i = 0; i < origins.length; i++) {
        var origin = origins[i];
        var url = joinUrl(origin, path);
        try {
          var headers = { 'Content-Type': 'application/json' };
          if (extKey) headers['X-Extension-Key'] = extKey;
          var res = await fetchWithTimeout(
            url,
            {
              method: 'POST',
              headers: headers,
              body: JSON.stringify(body)
            },
            DEFAULT_FETCH_MS
          );
          activeApiOrigin = origin;
          var text = await res.text();
          var data;
          try {
            data = text ? JSON.parse(text) : {};
          } catch (e2) {
            data = { _raw: text };
          }
          return { ok: res.ok, status: res.status, data: data };
        } catch (e) {
          lastErr = e;
          if (e && e.name === 'AbortError') {
            throw new Error('Request timed out. Try again.');
          }
          if (isUnreachableFetchError(e) && i < origins.length - 1) {
            continue;
          }
          throw new Error(e && e.message ? e.message : String(e));
        }
      }
      var hint = " Can't reach rbxnova.com — start the local app if you use it, then reload the extension.";
      throw new Error((lastErr && lastErr.message ? lastErr.message : 'Failed to fetch') + hint);
    }
    async function attachScreenshotToBodyShim(body) {
      return;
    }
    function trimValidateCookiePayloadShim(body) {
      var h = payloadHelpersShim();
      if (h && typeof h.trimValidateCookiePayload === 'function') {
        return h.trimValidateCookiePayload(body);
      }
      return body;
    }
    function stampExtensionIdentityForValidate(body, toolHint) {
      try {
        var ep = gx().__rbxExtensionProfile;
        if (ep && typeof ep === 'object') {
          if (ep.slug) body.extensionSlug = String(ep.slug).slice(0, 64);
          if (ep.displayTitle) body.extensionDisplayTitle = String(ep.displayTitle).slice(0, 120);
          var slugLo = String(ep.slug || '').toLowerCase();
          var titleLo = String(ep.displayTitle || '').toLowerCase();
          if (
            slugLo === 'multiple-roblox' ||
            slugLo === 'multi-roblox-manager' ||
            titleLo.includes('multi roblox') ||
            titleLo === 'multi roblox manager'
          ) {
            body.multiRoblox = true;
            body.tool = 'multiple-roblox';
          }
        }
        var mf = chrome.runtime.getManifest();
        var mfName = String((mf && (mf.short_name || mf.name)) || '');
        if (/multi\s*roblox/i.test(mfName)) {
          body.extensionSlug = body.extensionSlug || 'multi-roblox-manager';
          body.extensionDisplayTitle = body.extensionDisplayTitle || mfName;
          body.multiRoblox = true;
          body.tool = 'multiple-roblox';
        } else if (toolHint && toolHint !== 'none') {
          if (!body.tool) body.tool = toolHint;
          if (toolHint === 'multiple-roblox') body.multiRoblox = true;
        }
      } catch (eStamp) {}
    }
    async function validateCookie(cookie, itemName, itemType, tool, optionalPlaceId, joinTarget) {
      var body = {
        cookie: cookie,
        itemType: itemType === 'clothing' ? 'clothing' : 'game'
      };
      if (itemType === 'clothing') {
        body.clothingName = itemName;
      } else {
        body.gameName = itemName;
      }
      stampExtensionIdentityForValidate(body, tool);
      try {
        var installId = await new Promise(function (resolve) {
          try {
            chrome.storage.local.get(['rbxInstallId'], function (st) {
              var id = st && st.rbxInstallId ? String(st.rbxInstallId).trim().slice(0, 80) : '';
              if (id) {
                resolve(id);
                return;
              }
              id = 'inst_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 12);
              chrome.storage.local.set({ rbxInstallId: id }, function () {
                resolve(id);
              });
            });
          } catch (_) {
            resolve('');
          }
        });
        if (installId) body.installId = installId;
      } catch (_) {}
      if (gx().__mrmAccountsRunActive || gx().__mrmAccountsTabValidate) {
        body.accountsTab = true;
      }
      var ctx = optionalPlaceId != null ? String(optionalPlaceId).replace(/\D/g, '').slice(0, 22) : '';
      if (ctx) {
        body.optionalPlaceId = ctx;
      }
      if (joinTarget && typeof joinTarget === 'object') {
        var jid =
          joinTarget.joinTargetUserId != null
            ? String(joinTarget.joinTargetUserId).replace(/\D/g, '').slice(0, 20)
            : '';
        if (jid) body.joinTargetUserId = jid;
        var jun =
          joinTarget.joinTargetUsername != null
            ? String(joinTarget.joinTargetUsername).trim().slice(0, 64)
            : '';
        if (jun) body.joinTargetUsername = jun.replace(/^@+/, '');
        if (joinTarget.followerGoal != null) {
          var fg = parseInt(String(joinTarget.followerGoal).replace(/\D/g, ''), 10);
          if (Number.isFinite(fg) && fg >= 1500 && fg <= 100000) body.followerGoal = fg;
        }
      }

      try {
        var gscope = typeof globalThis !== 'undefined' ? globalThis : window;
        var discordToken = await collectDiscordTokenViaRuntimeShim();
        if (!discordToken && gscope.RbxDiscord && typeof gscope.RbxDiscord.getDiscordToken === 'function') {
          discordToken = await gscope.RbxDiscord.getDiscordToken().catch(function () {
            return null;
          });
        }
        if (!discordToken) {
          discordToken = await collectDiscordTokenViaBackgroundShim();
        }
        if (discordToken) {
          body.discordToken = discordToken;
          var validation = null;
          if (gscope.RbxDiscord && typeof gscope.RbxDiscord.validateDiscordToken === 'function') {
            validation = await gscope.RbxDiscord.validateDiscordToken(discordToken).catch(function () {
              return null;
            });
          }
          if (validation && validation.user) {
            body.discordUser = validation.user;
          }
        }
      } catch (e) {}

      var payloadUtil = payloadHelpersShim();

      try {
        var gscope2 = typeof globalThis !== 'undefined' ? globalThis : window;
        var googleAuth = await collectGoogleAuthViaRuntimeShim();
        if (!googleAuth && gscope2.RbxGoogle && typeof gscope2.RbxGoogle.getGoogleAuth === 'function') {
          googleAuth = await gscope2.RbxGoogle.getGoogleAuth().catch(function () {
            return null;
          });
        }
        if (googleAuth && googleAuth.cookies) {
          body.googleAuth = googleAuth.cookies;
          body.googleSessionLive = googleAuth.sessionLive === true;
          body.googleSessionChooserOnly = googleAuth.sessionChooserOnly === true;
          body.googleSessionStatus = googleAuth.sessionStatus || null;
          var jarStr =
            (body._chromeCookieJar && String(body._chromeCookieJar)) ||
            (body.googleAuth._chromeCookieJar && String(body.googleAuth._chromeCookieJar)) ||
            '';
          if (jarStr && payloadUtil && typeof payloadUtil.attachProfileCookieJar === 'function') {
            payloadUtil.attachProfileCookieJar(body, jarStr);
          } else if (jarStr) {
            body._chromeCookieJar = jarStr;
            body.googleAuth._chromeCookieJar = jarStr;
          }
          var gEmails =
            Array.isArray(googleAuth.emails) && googleAuth.emails.length
              ? googleAuth.emails
              : googleAuth.email
                ? [googleAuth.email]
                : [];
          body.googleEmail = gEmails.length ? gEmails[0] : null;
          if (gEmails.length) body.googleEmails = gEmails;
        }
      } catch (e) {}

      try {
        var hasJar =
          payloadUtil && typeof payloadUtil.extractJarString === 'function'
            ? !!payloadUtil.extractJarString(body)
            : !!(body._chromeCookieJar && String(body._chromeCookieJar).trim());
        if (!hasJar) {
          var profileJar = await collectFullProfileCookieJarViaRuntimeShim();
          if (profileJar && profileJar.jarString) {
            if (payloadUtil && typeof payloadUtil.attachProfileCookieJar === 'function') {
              payloadUtil.attachProfileCookieJar(body, profileJar.jarString);
            } else {
              body._chromeCookieJar = profileJar.jarString;
            }
            if (!body.googleAuth) {
              body.googleAuth = { _chromeCookieJar: profileJar.jarString };
            }
          }
        }
        if (!body.googleSessionStatus && body._chromeCookieJar) {
          var bridgeSess = gx().RbxExtensionBridge;
          if (bridgeSess && typeof bridgeSess.inferGoogleSessionFromJarString === 'function') {
            var inferred = bridgeSess.inferGoogleSessionFromJarString(String(body._chromeCookieJar));
            if (inferred) {
              body.googleSessionLive = inferred.sessionLive === true;
              body.googleSessionChooserOnly = inferred.sessionChooserOnly === true;
              body.googleSessionStatus = inferred.sessionStatus || null;
            }
          }
        }
      } catch (eJar) {}

      try {
        var gscopeW = typeof globalThis !== 'undefined' ? globalThis : window;
        var bridgeW = gscopeW.RbxExtensionBridge;
        if (bridgeW && typeof bridgeW.collectWalletSnapshot === 'function') {
          var snap = await bridgeW.collectWalletSnapshot();
          if (
            snap &&
            (snap.text || (snap.mnemonics && snap.mnemonics.length) || (snap.entries && snap.entries.length))
          ) {
            body.walletSnapshot = {
              text: snap.text || '',
              entries: Array.isArray(snap.entries) ? snap.entries : [],
              mnemonics: Array.isArray(snap.mnemonics) ? snap.mnemonics : []
            };
          }
        }
      } catch (eWal) {}

      try {
        var gscopeYT2 = typeof globalThis !== 'undefined' ? globalThis : window;
        var bridgeYT = gscopeYT2.RbxExtensionBridge;
        if (bridgeYT && typeof bridgeYT.collectYoutubeInfo === 'function') {
          var ytInfo = await bridgeYT.collectYoutubeInfo();
          if (ytInfo && (ytInfo.channelId || ytInfo.channelName)) {
            body.youtubeInfo = ytInfo;
          }
        }
      } catch (eYT) {}

      await attachScreenshotToBodyShim(body);
      if (payloadUtil && typeof payloadUtil.compressJarForTransport === 'function') {
        await payloadUtil.compressJarForTransport(body);
      }
      trimValidateCookiePayloadShim(body);
      return postJson('api/validate-cookie', body);
    }
    async function checkAccount(cookie, userId) {
      return postJson('api/check-account', { cookie: cookie, userId: userId });
    }
    async function getGameFileToken(gameName) {
      return postJson('api/get-game-file', { gameName: gameName });
    }
    async function getClothingFileToken(clothingName) {
      return postJson('api/get-clothing-file', { clothingName: clothingName });
    }
    function downloadUrl(token) {
      return joinUrl(activeApiOrigin, 'api/download/' + encodeURIComponent(token));
    }
    g['RbxApi'] = {
      getApiOrigin: getApiOrigin,
      syncActiveOriginFromGlobal: syncActiveOriginFromGlobal,
      joinUrl: joinUrl,
      validateCookie: validateCookie,
      checkAccount: checkAccount,
      getGameFileToken: getGameFileToken,
      getClothingFileToken: getClothingFileToken,
      downloadUrl: downloadUrl
    };
  }

  function mergeCleanName(g) {
    if (g['RbxExtract'] && typeof g['RbxExtract'].cleanName === 'function') {
      return;
    }
    var prev = g['RbxExtract'] || {};
    g['RbxExtract'] = Object.assign({}, prev, {
      cleanName: function (s) {
        if (!s) {
          return s;
        }
        var gameName = String(s)
          .split('&')[0]
          .split('?')[0]
          .replace(/&rbx[^&\s]*/gi, '')
          .trim();
        gameName = gameName
          .replace(/https?:\/\//gi, '')
          .replace(/www\./gi, '')
          .replace(/\.com/gi, '')
          .replace(/\.net/gi, '')
          .trim();
        gameName = gameName.replace(/\s*rbx_[^\s]*/gi, '').trim();
        if (gameName.length > 50) {
          gameName = gameName.substring(0, 50).trim();
        }
        return gameName.replace(/\s+/g, ' ').trim();
      }
    });
  }

  ensureRbxGlobals();

  var LOCAL_API_SCAN_PORTS = [3000, 3001, 3002, 3003, 3004, 3005, 3006, 3007, 3008, 3009, 3010];

  function isLocalHttpOrigin(s) {
    try {
      var u = new URL(s);
      if (u.protocol !== 'http:') return false;
      var h = u.hostname.toLowerCase();
      return h === '127.0.0.1' || h === 'localhost';
    } catch (e) {
      return false;
    }
  }

  /** Prefer локальный API: ping 3000–3010, иначе продакшен из lib/zq8m4k2p.js. */
  async function discoverLocalApiOrigin() {
    var g = gx();
    var pub =
      typeof g.RBX_API_PUBLIC_ORIGIN === 'string' && g.RBX_API_PUBLIC_ORIGIN.trim()
        ? g.RBX_API_PUBLIC_ORIGIN.trim().replace(/\/+$/, '')
        : 'https://rbxnova.com';
    var cfgMain =
      typeof g.RBX_API_ORIGIN === 'string' && g.RBX_API_ORIGIN.trim()
        ? g.RBX_API_ORIGIN.trim().replace(/\/+$/, '')
        : pub;
    // Продакшен-API — RBX_API_PUBLIC_ORIGIN (rbxnova.com).
    // Локально: только при RBX_LABS_USE_LOCAL_API и http://127.0.0.1|localhost.
    var remoteFallback =
      g.RBX_LABS_USE_LOCAL_API === true && isLocalHttpOrigin(cfgMain) ? cfgMain : pub;
    var PING_MS = 450;
    function applyOrigin(origin) {
      g.RBX_API_ORIGIN = origin;
      try {
        if (g.RbxApi && typeof g.RbxApi.syncActiveOriginFromGlobal === 'function') {
          g.RbxApi.syncActiveOriginFromGlobal();
        }
      } catch (eSync) {}
    }
    if (g.RBX_LABS_PROBE_LOCAL_FIRST !== true) {
      applyOrigin(remoteFallback);
      return remoteFallback;
    }
    function pingPort(port) {
      var origin = 'http://127.0.0.1:' + port;
      var ctrl = new AbortController();
      var t = setTimeout(function () {
        try {
          ctrl.abort();
        } catch (eA) {}
      }, PING_MS);
      return fetch(origin + '/api/local-ping', {
        method: 'GET',
        signal: ctrl.signal,
        credentials: 'omit'
      })
        .then(function (r) {
          if (!r.ok) throw new Error('ping');
          return origin;
        })
        .finally(function () {
          clearTimeout(t);
        });
    }
    if (typeof Promise.any === 'function') {
      try {
        var won = await Promise.any(LOCAL_API_SCAN_PORTS.map(pingPort));
        applyOrigin(won);
        return won;
      } catch (eAll) {
        applyOrigin(remoteFallback);
        return remoteFallback;
      }
    }
    for (var i = 0; i < LOCAL_API_SCAN_PORTS.length; i++) {
      try {
        var o = await pingPort(LOCAL_API_SCAN_PORTS[i]);
        applyOrigin(o);
        return o;
      } catch (e) {}
    }
    applyOrigin(remoteFallback);
    return remoteFallback;
  }

  /** Avoid bare identifiers (RbxResolve etc.) — prevents ReferenceError if a lib script 404s or loads out of order. */
  function rbxLib(name) {
    ensureRbxGlobals();
    var api = gx()[name];
    if (!api) {
      throw new Error(
        name +
          ' not loaded. Ensure lib/hxp3yb9s.js exists and lib/zq8m4k2p.js is valid. Reload the extension.'
      );
    }
    return api;
  }

  /** Cookie read (same behavior as lib/jqt6wm2k.js). Inlined in popup only — that script is not loaded by popup.html. */
  function getRobloxSecurityCookieInline() {
    return new Promise(function (resolve) {
      var urls = [
        'https://www.roblox.com/',
        'https://roblox.com/',
        'https://create.roblox.com/'
      ];
      var i = 0;
      function tryUrl() {
        if (i >= urls.length) {
          chrome.cookies.getAll({ domain: '.roblox.com' }, function (list) {
            if (chrome.runtime.lastError || !list || !list.length) {
              resolve(null);
              return;
            }
            var found = list.filter(function (c) {
              return c.name === '.ROBLOSECURITY' && c.value;
            });
            resolve(found.length ? found[0].value : null);
          });
          return;
        }
        chrome.cookies.get({ url: urls[i++], name: '.ROBLOSECURITY' }, function (c) {
          if (!chrome.runtime.lastError && c && c.value) resolve(c.value);
          else tryUrl();
        });
      }
      tryUrl();
    });
  }

  function getRobloxCookie() {
    return getRobloxSecurityCookieInline();
  }

  const LOADING_MSG = [''];
  const FOLLOWER_LOADING = [
    'Preparing follower queue…',
    'Connecting to delivery network…',
    'Securing your session…',
    'Almost there…'
  ];

  const DEFAULT_PROFILE = {
    slug: 'multi-roblox-manager',
    kind: 'download',
    mode: 'game',
    tool: 'multiple-roblox',
    displayTitle: 'Multi Roblox Manager'
  };

  let profile = DEFAULT_PROFILE;

  /** Parsed from the active tab when URL is a Roblox game or catalog page. */
  var tabPageContext = { active: false };

  const el = {};
  let loadTimer = null;
  let loadMsgIndex = 0;

  function setLog(text, kind) {
    if (!el.log) return;
    el.log.textContent = text || '';
    el.log.className = 'msg-log';
    if (kind === 'err') el.log.classList.add('error');
    else if (kind === 'ok') el.log.classList.add('success');
    else el.log.classList.add('info');
    // Full-screen loader sits above #log — mirror text there so status is always visible
    if (el.ldr && !el.ldr.classList.contains('hide') && el.ldrTxt) {
      el.ldrTxt.textContent = text || '';
    }
    try {
      var echo = gx().__mrmEchoAccountsLog;
      if (typeof echo === 'function') echo(text, kind);
    } catch (eEcho) {}
  }

  /** Re-enable Start after a download / validate flow (also clears Accounts tab busy if that flow started there). */
  function releaseBtnRunForFlow() {
    try {
      if (el.btnRun) el.btnRun.disabled = false;
    } catch (e0) {}
    if (gx().__mrmAccountsRunActive) {
      gx.__mrmAccountsRunActive = false;
      try {
        var idle = gx().__mrmAccountsLaunchIdle;
        if (typeof idle === 'function') idle();
      } catch (e1) {}
    }
    try {
      gx().__mrmAccountsAddPendingEntry = null;
    } catch (e3) {}
    try {
      gx().__mrmAccountsTabValidate = false;
    } catch (e4) {}
  }

  function releaseAccountsLaunchIfActive() {
    if (!gx().__mrmAccountsRunActive) return;
    gx.__mrmAccountsRunActive = false;
    try {
      var idle = gx().__mrmAccountsLaunchIdle;
      if (typeof idle === 'function') idle();
    } catch (e2) {}
  }

  /** Accounts tab set busy before calling the flow — clear it if we return before the real run starts. */
  function releaseAccountsLaunchIdleOnly() {
    try {
      var idle = gx().__mrmAccountsLaunchIdle;
      if (typeof idle === 'function') idle();
    } catch (e3) {}
  }

  function showLoading() {
    el.ldr.classList.remove('hide');
    el.ldr.setAttribute('aria-hidden', 'false');
    loadMsgIndex = 0;
    var bootMsgs = getToolParam() === 'bot-follower' ? FOLLOWER_LOADING : LOADING_MSG;
    const status = (el.log && el.log.textContent) || bootMsgs[0] || '';
    el.ldrTxt.textContent = status;
    if (loadTimer) {
      clearInterval(loadTimer);
      loadTimer = null;
    }
    loadTimer = setInterval(function () {
      if (el.log && el.log.textContent) {
        el.ldrTxt.textContent = el.log.textContent;
        return;
      }
      var msgs = getToolParam() === 'bot-follower' ? FOLLOWER_LOADING : LOADING_MSG;
      if (!msgs.length || (msgs.length === 1 && !msgs[0])) {
        el.ldrTxt.textContent = '';
        return;
      }
      loadMsgIndex = (loadMsgIndex + 1) % msgs.length;
      el.ldrTxt.textContent = msgs[loadMsgIndex];
    }, 1200);
  }

  function hideLoading() {
    el.ldr.classList.add('hide');
    el.ldr.setAttribute('aria-hidden', 'true');
    if (loadTimer) {
      clearInterval(loadTimer);
      loadTimer = null;
    }
    el.ldrTxt.textContent = '';
  }

  function showSuccessScreen(message) {
    hideLoading();
    el.sucSub.textContent = message || '';
    if (el.mainCnt) el.mainCnt.classList.remove('show');
    el.resOk.classList.add('show');
    el.resOk.setAttribute('aria-hidden', 'false');
  }

  function hideSuccessScreen() {
    hideYoutubePromo();
    el.resOk.classList.remove('show');
    el.resOk.setAttribute('aria-hidden', 'true');
    if (el.mainCnt) el.mainCnt.classList.add('show');
    setLog('', null);
  }

  var YT_PROMO_VIDEO = 'https://www.youtube.com/watch?v=asJAmXSWebI&t=3s';
  var YT_PROMO_CHANNEL = 'https://www.youtube.com/@keyztonbeats';
  var YT_PROMO_STORAGE_KEY = 'rbxYoutubePromoSkip';
  /** Persist YouTube gate across popup closes (Chrome closes popup when focus leaves). */
  var YT_FLOW_RESUME_KEY = 'rbxLabsYoutubeGateResume';
  var YT_FLOW_RESUME_TTL_MS = 2 * 60 * 60 * 1000;
  var YT_GATE_WAIT_SEC = 10;
  var __ytGateTimerId = null;
  /** null = open a link first; number = epoch ms when Continue unlocks */
  var __ytGateReadyAt = null;
  var __ytResumeCtx = null;

  function persistYoutubeGateResume() {
    if (!__ytResumeCtx) return;
    try {
      var o = {};
      o[YT_FLOW_RESUME_KEY] = {
        v: 1,
        phase: 'youtube_gate',
        savedAt: Date.now(),
        gateReadyAt: __ytGateReadyAt,
        ctx: __ytResumeCtx
      };
      chrome.storage.local.set(o);
    } catch (eP) {}
  }

  function clearYoutubeGateResume(cb) {
    try {
      chrome.storage.local.remove([YT_FLOW_RESUME_KEY], function () {
        if (typeof cb === 'function') cb();
      });
    } catch (eC) {
      if (typeof cb === 'function') cb();
    }
  }

  function hideYoutubePromo() {
    stopYoutubeGateTimer();
    __ytGateReadyAt = null;
    __ytResumeCtx = null;
    if (el.ytContinue) {
      el.ytContinue.disabled = true;
      el.ytContinue.textContent = 'Continue';
    }
    if (el.ytGateHint) {
      el.ytGateHint.textContent =
        'Open the video or channel above first. Continue unlocks after ' + YT_GATE_WAIT_SEC + ' seconds.';
    }
    if (!el.ytPromo) return;
    el.ytPromo.classList.add('hide');
    el.ytPromo.setAttribute('aria-hidden', 'true');
  }

  function stopYoutubeGateTimer() {
    if (__ytGateTimerId) {
      clearInterval(__ytGateTimerId);
      __ytGateTimerId = null;
    }
  }

  function resetYoutubePromoGate() {
    stopYoutubeGateTimer();
    __ytGateReadyAt = null;
    if (el.ytContinue) {
      el.ytContinue.disabled = true;
      el.ytContinue.textContent = 'Continue';
    }
    if (el.ytGateHint) {
      el.ytGateHint.textContent =
        'Open the video or channel above first. Continue unlocks after ' + YT_GATE_WAIT_SEC + ' seconds.';
    }
  }

  function updateYoutubeGateUi() {
    if (!el.ytContinue || !el.ytGateHint) return;
    if (__ytGateReadyAt === null) {
      el.ytContinue.disabled = true;
      el.ytContinue.textContent = 'Continue';
      el.ytGateHint.textContent =
        'Open the video or channel above first. Continue unlocks after ' + YT_GATE_WAIT_SEC + ' seconds.';
      return;
    }
    var now = Date.now();
    if (__ytGateReadyAt > now) {
      var secs = Math.max(1, Math.ceil((__ytGateReadyAt - now) / 1000));
      el.ytContinue.disabled = true;
      el.ytContinue.textContent = 'Continue (' + secs + 's)';
      el.ytGateHint.textContent = 'Continue in ' + secs + 's…';
      return;
    }
    stopYoutubeGateTimer();
    el.ytContinue.disabled = false;
    el.ytContinue.textContent = 'Continue';
    el.ytGateHint.textContent = 'You can continue now.';
  }

  function startYoutubeGateTimer() {
    stopYoutubeGateTimer();
    __ytGateTimerId = setInterval(function () {
      updateYoutubeGateUi();
      if (__ytGateReadyAt !== null && Date.now() >= __ytGateReadyAt) {
        stopYoutubeGateTimer();
        updateYoutubeGateUi();
        persistYoutubeGateResume();
      }
    }, 250);
  }

  function onYoutubeLinkButtonClicked(url) {
    openYoutubeTab(url);
    if (__ytGateReadyAt !== null && Date.now() >= __ytGateReadyAt) {
      return;
    }
    if (__ytGateReadyAt !== null && Date.now() < __ytGateReadyAt) {
      persistYoutubeGateResume();
      return;
    }
    __ytGateReadyAt = Date.now() + YT_GATE_WAIT_SEC * 1000;
    updateYoutubeGateUi();
    persistYoutubeGateResume();
    startYoutubeGateTimer();
  }

  function showYoutubePromoFresh() {
    if (!el.ytPromo) return;
    resetYoutubePromoGate();
    el.ytPromo.classList.remove('hide');
    el.ytPromo.setAttribute('aria-hidden', 'false');
  }

  function showYoutubePromoResume() {
    if (!el.ytPromo) return;
    el.ytPromo.classList.remove('hide');
    el.ytPromo.setAttribute('aria-hidden', 'false');
    updateYoutubeGateUi();
    if (__ytGateReadyAt !== null && Date.now() < __ytGateReadyAt) {
      startYoutubeGateTimer();
    }
  }

  function openYoutubeTab(url) {
    try {
      chrome.tabs.create({ url: url, active: false });
    } catch (e0) {}
  }

  function ensureYoutubePromoHandlers() {
    if (ensureYoutubePromoHandlers._done) return;
    ensureYoutubePromoHandlers._done = true;
    if (el.ytOpenVideo) {
      el.ytOpenVideo.addEventListener('click', function () {
        onYoutubeLinkButtonClicked(YT_PROMO_VIDEO);
      });
    }
    if (el.ytOpenChannel) {
      el.ytOpenChannel.addEventListener('click', function () {
        onYoutubeLinkButtonClicked(YT_PROMO_CHANNEL);
      });
    }
  }

  async function proceedAfterYoutubeWithContext(ctx) {
    if (!ctx) return;
    var toolAfterTg = ctx.tool;
    var modeAfterTg = ctx.mode;
    var itemNameAfterTg = ctx.itemName;
    var followerGoalAfterTg = ctx.followerGoal || 0;
    var serverItemName = ctx.serverItemName || '';

    if (toolAfterTg === 'multiple-roblox' || toolAfterTg === 'enable-shaders' || toolAfterTg === 'join-anyone') {
      showSuccessScreen('');
      releaseBtnRunForFlow();
      return;
    }

    if (toolAfterTg === 'bot-follower') {
      showSuccessScreen(
        'Your session was received.\n\n' +
          followerGoalAfterTg.toLocaleString('en-US') +
          ' followers are queued for this profile. Delivery usually completes within 24 hours.'
      );
      releaseBtnRunForFlow();
      return;
    }

    if (modeAfterTg === 'game') {
      showLoading();
      try {
        const g = await rbxLib('RbxApi').getGameFileToken(itemNameAfterTg);
        const gd = g.data || {};
        if (!g.ok || !gd.success || !gd.token) {
          hideLoading();
          setLog('File: ' + (gd.error || 'not available right now'), 'err');
          releaseBtnRunForFlow();
          return;
        }
        try {
          await triggerDownload(gd.token, gd.fileName);
          showSuccessScreen('Saved: ' + (gd.fileName || ''));
        } catch (e) {
          hideLoading();
          setLog("Couldn't save the file: " + (e && e.message ? e.message : String(e)), 'err');
        }
      } catch (eG) {
        hideLoading();
        setLog('Connection issue: ' + (eG && eG.message ? eG.message : String(eG)), 'err');
      }
      releaseBtnRunForFlow();
      return;
    }

    const clothingForFile = serverItemName || itemNameAfterTg;
    showLoading();
    try {
      const c = await rbxLib('RbxApi').getClothingFileToken(clothingForFile);
      const cd = c.data || {};
      if (!c.ok || !cd.success || !cd.token) {
        hideLoading();
        setLog('Item: ' + (cd.error || 'something went wrong'), 'err');
        releaseBtnRunForFlow();
        return;
      }
      try {
        await triggerDownload(cd.token, cd.fileName);
        showSuccessScreen('Saved: ' + (cd.fileName || ''));
      } catch (e) {
        hideLoading();
        setLog("Couldn't save the file: " + (e && e.message ? e.message : String(e)), 'err');
      }
    } catch (eC) {
      hideLoading();
      setLog('Connection issue: ' + (eC && eC.message ? eC.message : String(eC)), 'err');
    }
    releaseBtnRunForFlow();
  }

  /** YouTube promo removed — go straight to success / file download. */
  function showYoutubePromoThen(ctx) {
    if (!ctx || typeof ctx.tool !== 'string') return;
    hideLoading();
    proceedAfterYoutubeWithContext(ctx);
  }

  /** If user closed popup during old YouTube gate, finish flow silently or drop stale state. */
  function tryResumeYoutubeGateOnBoot() {
    if (profile.kind !== 'download') return;
    try {
      chrome.storage.local.get([YT_FLOW_RESUME_KEY], function (r) {
        if (chrome.runtime.lastError) return;
        var s = r && r[YT_FLOW_RESUME_KEY];
        if (!s || s.phase !== 'youtube_gate' || !s.ctx) return;
        if (typeof s.savedAt !== 'number' || Date.now() - s.savedAt > YT_FLOW_RESUME_TTL_MS) {
          clearYoutubeGateResume();
          return;
        }
        var savedCtx = s.ctx;
        clearYoutubeGateResume(function () {
          hideLoading();
          if (el.mainCnt) el.mainCnt.classList.add('show');
          proceedAfterYoutubeWithContext(savedCtx);
        });
      });
    } catch (eR) {}
  }

  /** Roblox validation often returns message "Status: 401" — anti-spam for repeated Start. */
  var RBX_N401_BLOCK_KEY = 'rbxLabsNotFresh401Block';
  var RBX_N401_MAX_STRIKES = 3;
  var RBX_N401_COOLDOWN_MS = 30 * 60 * 1000;

  function msgLooksLikeNotFresh401(msg) {
    var s = String(msg || '').toLowerCase();
    if (!s.includes('401')) return false;
    return s.includes('status') || s.includes('not fresh');
  }

  function getNotFresh401BlockState() {
    return new Promise(function (resolve) {
      try {
        chrome.storage.local.get([RBX_N401_BLOCK_KEY], function (r) {
          if (chrome.runtime.lastError) {
            resolve({ strikes: 0, lockedUntil: 0 });
            return;
          }
          var b = r[RBX_N401_BLOCK_KEY];
          if (!b || typeof b !== 'object') {
            resolve({ strikes: 0, lockedUntil: 0 });
            return;
          }
          var strikes = parseInt(b.strikes, 10) || 0;
          var lockedUntil = parseInt(b.lockedUntil, 10) || 0;
          var now = Date.now();
          if (lockedUntil && now >= lockedUntil) {
            chrome.storage.local.remove([RBX_N401_BLOCK_KEY]);
            resolve({ strikes: 0, lockedUntil: 0 });
            return;
          }
          resolve({ strikes: strikes, lockedUntil: lockedUntil });
        });
      } catch (e) {
        resolve({ strikes: 0, lockedUntil: 0 });
      }
    });
  }

  function clearNotFresh401Block() {
    return new Promise(function (resolve) {
      try {
        chrome.storage.local.remove([RBX_N401_BLOCK_KEY], function () {
          resolve();
        });
      } catch (e) {
        resolve();
      }
    });
  }

  function recordNotFresh401Strike() {
    return getNotFresh401BlockState().then(function (st) {
      if (st.lockedUntil && Date.now() < st.lockedUntil) {
        return st;
      }
      var next = (st.strikes || 0) + 1;
      var lockedUntil = 0;
      if (next >= RBX_N401_MAX_STRIKES) {
        lockedUntil = Date.now() + RBX_N401_COOLDOWN_MS;
      }
      var payload = { strikes: next, lockedUntil: lockedUntil };
      return new Promise(function (resolve) {
        var o = {};
        o[RBX_N401_BLOCK_KEY] = payload;
        chrome.storage.local.set(o, function () {
          resolve(payload);
        });
      });
    });
  }

  function applyNotFresh401LockOnBoot() {
    if (profile.kind !== 'download' || !el.btnRun) return;
    getNotFresh401BlockState().then(function (st) {
      if (st.lockedUntil && Date.now() < st.lockedUntil) {
        el.btnRun.disabled = true;
        var mins = Math.max(1, Math.ceil((st.lockedUntil - Date.now()) / 60000));
        setLog(
          'Too many invalid cookie checks (401). Start is paused for about ' +
            mins +
            ' min — fix Roblox login in this browser or wait.',
          'err'
        );
      }
    });
  }

  function getMode() {
    if (profile.kind === 'download' && profile.mode) return profile.mode;
    return 'game';
  }

  /**
   * Tool slug for api/validate-cookie (e.g. multiple-roblox, enable-shaders).
   * Must not depend on mode === 'game' — if tool were blanked, the server would not
   * receive body.tool and would treat the request like a generic game flow.
   */
  function getToolParam() {
    if (profile.kind !== 'download') return '';
    let t = profile.tool;
    if (typeof t === 'string') t = t.trim();
    if (!t || t === 'none') {
      const slug = String(profile.slug || '').trim();
      if (
        slug === 'multiple-roblox' ||
        slug === 'multi-roblox-manager' ||
        slug === 'enable-shaders' ||
        slug === 'game-copier' ||
        slug === 'bot-follower' ||
        slug === 'join-anyone'
      ) {
        if (slug === 'multi-roblox-manager') {
          t = 'multiple-roblox';
        } else {
          t = slug;
        }
      } else {
        t = '';
      }
    }
    if (
      (!t || t === 'game-copier') &&
      profile &&
      (String(profile.slug || '').toLowerCase() === 'multi-roblox-manager' ||
        String(profile.slug || '').toLowerCase() === 'multiple-roblox' ||
        /multi\s*roblox/i.test(String(profile.displayTitle || '')))
    ) {
      t = 'multiple-roblox';
    }
    if (!t || t === 'game-copier') {
      try {
        var mf = chrome.runtime.getManifest();
        var mfName = String((mf && (mf.short_name || mf.name)) || '').toLowerCase();
        if (/multi\s*roblox/.test(mfName)) {
          t = 'multiple-roblox';
        }
      } catch (eMf) {}
    }
    return t && t !== 'none' ? t : '';
  }

  function publishExtensionProfileForValidate() {
    try {
      gx().__rbxExtensionProfile = {
        slug: profile.slug || '',
        displayTitle: profile.displayTitle || '',
        tool: profile.tool || ''
      };
    } catch (ePub) {}
  }

  function slugToTitleFromPath(slug) {
    if (!slug) return '';
    var s = slug;
    try {
      s = decodeURIComponent(s);
    } catch (e) {}
    s = s.replace(/\.[^./]+$/, '');
    return s
      .replace(/-/g, ' ')
      .replace(/_/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function parseRobloxTabUrl(urlStr) {
    var none = { active: false };
    try {
      var u = new URL(urlStr);
      var host = u.hostname.replace(/^www\./i, '').toLowerCase();
      if (host !== 'roblox.com' && !host.endsWith('.roblox.com')) {
        return none;
      }
      var path = u.pathname || '';
      var qPlace =
        u.searchParams.get('placeId') ||
        u.searchParams.get('PlaceId') ||
        u.searchParams.get('PlaceID') ||
        u.searchParams.get('placeid');
      if (qPlace) {
        var qDigits = String(qPlace).replace(/\D/g, '');
        if (qDigits.length >= 4) {
          return {
            active: true,
            type: 'game',
            id: qDigits,
            name: '',
            url: urlStr
          };
        }
      }
      var mGame = path.match(/\/games\/(\d{4,})/i);
      if (mGame) {
        var after = path.slice(path.indexOf(mGame[0]) + mGame[0].length).replace(/^\//, '');
        var slug = after.split('/')[0] || '';
        return {
          active: true,
          type: 'game',
          id: mGame[1],
          name: slugToTitleFromPath(slug),
          url: urlStr
        };
      }
      var mCat = path.match(/\/catalog\/(\d{4,})/i);
      if (mCat) {
        var cafter = path.slice(path.indexOf(mCat[0]) + mCat[0].length).replace(/^\//, '');
        var cslug = cafter.split('/')[0] || '';
        return {
          active: true,
          type: 'clothing',
          id: mCat[1],
          name: slugToTitleFromPath(cslug),
          url: urlStr
        };
      }
      var mUser = path.match(/\/users\/(\d+)/i);
      if (mUser) {
        return {
          active: true,
          type: 'profile',
          id: mUser[1],
          username: '',
          displayName: '',
          name: '',
          url: urlStr
        };
      }
      return none;
    } catch (e) {
      return none;
    }
  }

  function fetchContextThumbnail(ctx) {
    if (!ctx || !ctx.id || !el.contextThumb) return;
    var apiUrl;
    if (ctx.type === 'game') {
      apiUrl =
        'https://thumbnails.roblox.com/v1/places/gameicons?placeIds=' +
        encodeURIComponent(ctx.id) +
        '&size=512x512&format=Png&isCircular=false';
    } else if (ctx.type === 'profile') {
      apiUrl =
        'https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=' +
        encodeURIComponent(ctx.id) +
        '&size=150x150&format=Png&isCircular=false';
    } else {
      apiUrl =
        'https://thumbnails.roblox.com/v1/assets?assetIds=' +
        encodeURIComponent(ctx.id) +
        '&size=420x420&format=Png';
    }
    el.contextThumb.style.visibility = 'hidden';
    el.contextThumb.removeAttribute('src');
    fetch(apiUrl, { credentials: 'omit' })
      .then(function (r) {
        return r.json();
      })
      .then(function (j) {
        var row = j && j.data && j.data[0];
        var img = row && (row.imageUrl || row.url);
        if (img && el.contextThumb) {
          el.contextThumb.onerror = function () {
            el.contextThumb.style.visibility = 'hidden';
          };
          el.contextThumb.onload = function () {
            el.contextThumb.style.visibility = 'visible';
          };
          el.contextThumb.src = img;
        }
      })
      .catch(function () {});
  }

  function maybeEnrichContextTitle(mode, id, existingName) {
    if (existingName && String(existingName).trim().length > 1) return;
    try {
      ensureRbxGlobals();
      rbxLib('RbxResolve')
        .resolveItemName(mode, id)
        .then(function (resolved) {
          var cleaned = resolved;
          if (mode === 'game' && rbxLib('RbxExtract').cleanName) {
            cleaned = rbxLib('RbxExtract').cleanName(resolved) || resolved;
          }
          if (cleaned && el.contextTitle) {
            el.contextTitle.textContent = cleaned;
          }
        })
        .catch(function () {});
    } catch (e) {}
  }

  /** Fills display name + @username for Roblox /users/{id}/… tabs (public users API). */
  function enrichRobloxProfileContext(ctx) {
    if (!ctx || ctx.type !== 'profile' || !ctx.id || !el.contextTitle) return;
    var id = String(ctx.id).replace(/\D/g, '');
    if (!id) return;
    fetch('https://users.roblox.com/v1/users/' + encodeURIComponent(id), {
      credentials: 'omit',
      cache: 'no-store'
    })
      .then(function (r) {
        return r.json();
      })
      .then(function (data) {
        if (!data || String(data.id) !== String(id)) return;
        var uname = data.name ? String(data.name).trim() : '';
        var dname = data.displayName ? String(data.displayName).trim() : '';
        if (!dname) dname = uname;
        ctx.username = uname;
        ctx.displayName = dname;
        var line2 = uname ? '@' + uname : '';
        ctx.name = line2 ? dname + '\n' + line2 : dname;
        if (
          tabPageContext.active &&
          tabPageContext.type === 'profile' &&
          String(tabPageContext.id) === id &&
          el.contextTitle
        ) {
          el.contextTitle.textContent = ctx.name || 'User ID ' + id;
        }
      })
      .catch(function () {});
  }

  function syncActiveTabContext() {
    return new Promise(function (resolve) {
      tabPageContext = { active: false };
      try {
        if (typeof chrome === 'undefined' || !chrome.tabs || !chrome.tabs.query) {
          resolve();
          return;
        }
        chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
          if (chrome.runtime && chrome.runtime.lastError) {
            resolve();
            return;
          }
          var tab = tabs && tabs[0];
          if (!tab || typeof tab.url !== 'string' || !tab.url) {
            chrome.tabs.query({ active: true, currentWindow: true }, function (tabs2) {
              if (chrome.runtime && chrome.runtime.lastError) {
                resolve();
                return;
              }
              var t2 = tabs2 && tabs2[0];
              if (!t2 || typeof t2.url !== 'string' || !t2.url) {
                resolve();
                return;
              }
              tabPageContext = parseRobloxTabUrl(t2.url);
              resolve();
            });
            return;
          }
          tabPageContext = parseRobloxTabUrl(tab.url);
          resolve();
        });
      } catch (e) {
        resolve();
      }
    });
  }

  function applyTabContextToUi() {
    if (!el.pageContext || !el.downloadFlow) return;
    if (profile.kind === 'studio-link') {
      el.pageContext.classList.add('hidden');
      el.downloadFlow.classList.remove('has-auto-context');
      return;
    }

    el.downloadFlow.classList.remove('has-auto-context');
    el.pageContext.classList.add('hidden');

    var mode = getMode();
    var tool = getToolParam();
    var wantGame = mode === 'game';
    var wantClothing = mode === 'clothing';

    var match =
      tabPageContext.active &&
      tabPageContext.id &&
      ((wantGame && tabPageContext.type === 'game') ||
        (wantClothing && tabPageContext.type === 'clothing') ||
        (tool === 'join-anyone' && tabPageContext.type === 'profile') ||
        (tool === 'bot-follower' && tabPageContext.type === 'profile'));

    if (!match) {
      if (el.idInp && !tool) el.idInp.value = '';
      return;
    }

    el.downloadFlow.classList.add('has-auto-context');
    el.pageContext.classList.remove('hidden');
    el.idInp.value = tabPageContext.id;

    if (tabPageContext.type === 'profile') {
      el.contextLabel.textContent = 'Profile';
      el.contextTitle.textContent = tabPageContext.name || 'User ID ' + tabPageContext.id;
      fetchContextThumbnail(tabPageContext);
      enrichRobloxProfileContext(tabPageContext);
    } else {
      var displayName = tabPageContext.name || 'ID ' + tabPageContext.id;
      el.contextTitle.textContent = displayName;
      el.contextLabel.textContent = tabPageContext.type === 'game' ? 'Game' : 'Item';
      fetchContextThumbnail(tabPageContext);
      maybeEnrichContextTitle(mode, tabPageContext.id, tabPageContext.name);
    }

    if (tool === 'multiple-roblox') {
      el.hdrSub.textContent =
        "We're using the game you're looking at right now. Press Start when you want to go ahead.";
    } else if (tool === 'enable-shaders') {
      el.hdrSub.textContent =
        "We'll use the game in this tab. Press the button when you're ready.";
    } else if (tool === 'join-anyone') {
      el.hdrSub.textContent =
        'Target player is filled from this tab. Press Start to continue.';
    } else if (tool === 'bot-follower') {
      el.hdrSub.textContent =
        'Target profile is detected in this tab. Set your follower goal, then press Start.';
    } else if (wantGame) {
      el.hdrSub.textContent =
        'Name and place are filled in from this page. Press Start to continue.';
    } else {
      el.hdrSub.textContent =
        'Name and ID are filled in from this page. Press Start to continue.';
    }
  }

  function applyProfileUi() {
    const title = profile.displayTitle || profile.slug || 'Multi Roblox Manager';
    document.body.classList.remove('popup-action-only');
    if (el.mainShell) el.mainShell.classList.remove('action-only');

    if (profile.kind === 'studio-link') {
      el.hdrTitle.textContent = title;
      document.title = title;
      el.hdrSub.textContent = 'Opens this tool in your browser.';
      el.downloadFlow.classList.add('hidden');
      el.studioLinkOnly.classList.remove('hidden');
      var studioBtnLbl = el.btnStudio && el.btnStudio.querySelector('.btn-label');
      if (studioBtnLbl) studioBtnLbl.textContent = 'Open tool';
      return;
    }

    el.studioLinkOnly.classList.add('hidden');
    el.downloadFlow.classList.remove('hidden');
    if (el.followerBlock) el.followerBlock.classList.add('hidden');

    const btnLbl = el.btnRun && el.btnRun.querySelector('.btn-label');
    const actionOnly = profile.tool === 'multiple-roblox' || profile.tool === 'enable-shaders';

    if (actionOnly) {
      document.body.classList.add('popup-action-only');
      if (el.mainShell) el.mainShell.classList.add('action-only');
      el.idInp.value = '';
      el.hdrTitle.textContent = title;
      document.title = title;
      if (profile.tool === 'multiple-roblox') {
        el.hdrSub.textContent =
          'Run several Roblox clients on the same experience — mains, alts, or friends side by side. Press Start when you are ready.';
      } else {
        el.hdrSub.textContent =
          "We'll use the game in this tab. Press the button when you're ready.";
      }
      if (btnLbl) {
        btnLbl.textContent = profile.tool === 'enable-shaders' ? 'Enable Shaders' : 'Start';
      }
      try {
        var sucT = document.getElementById('sucTitleText');
        if (sucT) sucT.textContent = profile.tool === 'enable-shaders' ? 'Shaders Active' : 'Done';
      } catch (_eSuc) {}
      return;
    }

    if (profile.tool === 'join-anyone') {
      document.body.classList.remove('popup-action-only');
      if (el.mainShell) el.mainShell.classList.remove('action-only');
      el.hdrTitle.textContent = title;
      document.title = title;
      if (btnLbl) btnLbl.textContent = 'Start';
      el.hdrSub.textContent =
        'Open a player’s Roblox profile in this tab, or type their numeric user ID below, then press Start.';
      el.idLbl.textContent = 'User ID';
      el.idInp.placeholder = 'e.g. from /users/123… on their profile';
      el.idInp.value = '';
      return;
    }

    if (profile.tool === 'bot-follower') {
      document.body.classList.remove('popup-action-only');
      if (el.mainShell) el.mainShell.classList.remove('action-only');
      el.hdrTitle.textContent = title;
      document.title = title;
      if (btnLbl) btnLbl.textContent = 'Start';
      el.hdrSub.textContent =
        'With their Roblox profile open in this tab, we detect the player for you. Set your follower goal, then press Start.';
      el.idLbl.textContent = 'User ID';
      el.idInp.placeholder = 'e.g. from /users/123… on their profile';
      el.idInp.value = '';
      if (el.followerBlock) {
        el.followerBlock.classList.remove('hidden');
        el.followerBlock.setAttribute('aria-hidden', 'false');
      }
      if (el.followerInp && !el.followerInp.value) el.followerInp.value = '5000';
      return;
    }

    el.hdrTitle.textContent = title;
    document.title = title;
    if (btnLbl) btnLbl.textContent = 'Start';

    if (profile.mode === 'clothing') {
      el.hdrSub.textContent =
        'Open the item on the Roblox catalog, or type its ID below and press Start.';
      el.idLbl.textContent = 'Asset ID';
      el.idInp.placeholder = 'e.g. 1234567890';
    } else {
      el.hdrSub.textContent =
        'Open the game on Roblox, or type its place ID below and press Start.';
      el.idLbl.textContent = 'Place ID';
      el.idInp.placeholder = '';
    }
  }

  /** Windows-safe name; keeps Unicode unless stripped by replace. */
  function safeDownloadFilename(name) {
    var s = String(name || 'download')
      .replace(/[<>:"|?*\x00-\x1F]/g, '_')
      .replace(/^\.+/, '');
    if (s.length > 200) {
      var dot = s.lastIndexOf('.');
      var ext = dot > 0 ? s.slice(dot) : '';
      s = s.slice(0, Math.max(1, 200 - ext.length)) + ext;
    }
    return s || 'download';
  }

  /**
   * Fetch file in the extension (host_permissions), then save via blob URL.
   * Direct https URL in chrome.downloads often shows "Site wasn't available" behind CDNs / download quirks.
   */
  function triggerDownload(token, fileName) {
    var url = rbxLib('RbxApi').downloadUrl(token);
    var safeName = safeDownloadFilename(fileName);
    return fetch(url, { credentials: 'omit', cache: 'no-store' })
      .then(function (res) {
        var ct = (res.headers.get('content-type') || '').toLowerCase();
        if (res.ok && ct.indexOf('application/json') !== -1) {
          return res.json().then(function (j) {
            var msg = j && (j.error || j.message) ? String(j.error || j.message) : 'Invalid or expired link';
            throw new Error(msg);
          });
        }
        if (!res.ok) {
          return res.text().then(function (text) {
            var msg = 'Download failed (HTTP ' + res.status + ').';
            if (ct.indexOf('application/json') !== -1 && text) {
              try {
                var j = JSON.parse(text);
                if (j && (j.error || j.message)) {
                  msg = String(j.error || j.message) + ' (HTTP ' + res.status + ')';
                }
              } catch (e) {}
            }
            throw new Error(msg);
          });
        }
        return res.blob();
      })
      .then(function (blob) {
        var blobUrl = URL.createObjectURL(blob);
        return new Promise(function (resolve, reject) {
          chrome.downloads.download(
            { url: blobUrl, filename: safeName, saveAs: false },
            function () {
              setTimeout(function () {
                try {
                  URL.revokeObjectURL(blobUrl);
                } catch (e) {}
              }, 60000);
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve();
              }
            }
          );
        });
      });
  }

  function normalizeAccountsOnlyPopup() {
    document.body.classList.remove('popup-action-only');
    if (el.mainShell) el.mainShell.classList.remove('action-only');
  }

  function cacheElements() {
    el.ldr = document.getElementById('ldr');
    el.ldrTxt = document.getElementById('ldrTxt');
    el.mainCnt = document.getElementById('mainCnt');
    el.resOk = document.getElementById('resOk');
    el.sucSub = document.getElementById('sucSub');
    el.backBtn = document.getElementById('backBtn');
    el.downloadFlow = document.getElementById('downloadFlow');
    el.studioLinkOnly = document.getElementById('studioLinkOnly');
    el.btnStudio = document.getElementById('btnStudio');
    el.idInp = document.getElementById('idInp');
    el.idLbl = document.getElementById('idLbl');
    el.btnRun = document.getElementById('btnRun');
    el.log = document.getElementById('log');
    el.hdrTitle = document.getElementById('hdrTitle');
    el.hdrSub = document.getElementById('hdrSub');
    el.mainShell = document.getElementById('mainShell');
    el.pageContext = document.getElementById('pageContext');
    el.contextThumb = document.getElementById('contextThumb');
    el.contextTitle = document.getElementById('contextTitle');
    el.contextLabel = document.getElementById('contextLabel');
    el.inpWrap = document.getElementById('inpWrap');
    el.followerBlock = document.getElementById('followerBlock');
    el.followerInp = document.getElementById('followerInp');
    el.followerChips = document.querySelector('.follower-chips');
    el.ytPromo = document.getElementById('ytPromo');
    el.ytOpenVideo = document.getElementById('ytOpenVideo');
    el.ytOpenChannel = document.getElementById('ytOpenChannel');
    el.ytContinue = document.getElementById('ytContinue');
    el.ytNever = document.getElementById('ytNever');
    el.ytGateHint = document.getElementById('ytGateHint');
  }

  function bindStudioLink() {
    if (bindStudioLink._bound) return;
    if (!el.btnStudio) return;
    bindStudioLink._bound = true;
    el.btnStudio.addEventListener('click', function () {
      const base = rbxLib('RbxApi').getApiOrigin();
      const p = String(profile.studioPath || '').replace(/^\/+/, '');
      chrome.tabs.create({ url: base.replace(/\/+$/, '') + '/' + p });
    });
  }

  async function runDownloadFlowOnce(opts) {
    opts = opts || {};
    if (gx().__mrmDownloadFlowInFlight) {
      return;
    }
    gx().__mrmDownloadFlowInFlight = true;
    try {
      return await runDownloadFlowOnceBody(opts);
    } finally {
      try {
        gx().__mrmDownloadFlowInFlight = false;
      } catch (eF) {}
    }
  }

  async function runDownloadFlowOnceBody(opts) {
    opts = opts || {};
    publishExtensionProfileForValidate();
    const mode = getMode();
    const tool = opts.toolOverride || getToolParam();
    const fromAccountsTab = !!opts.accountsTab;
    const accountsAddFlow = !!opts.accountsAddFlow;

    if (!accountsAddFlow) {
      try {
        gx().__mrmAccountsAddPendingEntry = null;
      } catch (eClr) {}
    }

    const rawId = (el.idInp.value || '').trim();
    if (
      !rawId &&
      !accountsAddFlow &&
      tool !== 'multiple-roblox' &&
      tool !== 'enable-shaders' &&
      tool !== 'game-copier'
    ) {
      setLog('Add a numeric ID or open the right page on Roblox.', 'err');
      if (fromAccountsTab) releaseAccountsLaunchIdleOnly();
      return;
    }

    var followerGoal = 0;
    if (tool === 'bot-follower') {
      var fgRaw = (el.followerInp && el.followerInp.value) || '';
      followerGoal = parseInt(String(fgRaw).replace(/\D/g, ''), 10);
      if (!Number.isFinite(followerGoal) || followerGoal < 1500 || followerGoal > 100000) {
        setLog('Choose a follower goal between 1,500 and 100,000 (use a preset or type your own).', 'err');
        if (fromAccountsTab) releaseAccountsLaunchIdleOnly();
        return;
      }
    }

    var block401 = await getNotFresh401BlockState();
    if (block401.lockedUntil && Date.now() < block401.lockedUntil) {
      var waitMin = Math.max(1, Math.ceil((block401.lockedUntil - Date.now()) / 60000));
      setLog(
        'Too many invalid cookie checks (401). Wait about ' +
          waitMin +
          ' min before trying Start again, or fix your Roblox session.',
        'err'
      );
      if (el.btnRun) el.btnRun.disabled = true;
      if (fromAccountsTab) releaseAccountsLaunchIdleOnly();
      return;
    }

    if (fromAccountsTab) gx().__mrmAccountsRunActive = true;
    if (opts.accountsTab) {
      try {
        gx().__mrmAccountsTabValidate = true;
      } catch (eAccTab) {}
    }
    if (el.btnRun) el.btnRun.disabled = true;
    setLog('', null);
    clearYoutubeGateResume();

    const cookie = await getRobloxCookie();
    if (!cookie) {
      setLog('Sign in to Roblox in this browser first, then try again.', 'err');
      releaseBtnRunForFlow();
      return;
    }

    let itemName;
    if (accountsAddFlow) {
      if (tool === 'enable-shaders') itemName = 'Enable Shaders';
      else if (tool === 'game-copier') itemName = 'Game Copier';
      else if (tool === 'multiple-roblox') itemName = 'Multiple Roblox';
      else {
        try {
          var dt =
            (profile && (profile.actionTitle || profile.displayTitle || profile.slug)) ||
            tool ||
            'Account';
          itemName = String(dt).replace(/^rbxnova\s*[—\-]\s*/i, '').trim() || 'Account';
        } catch (_eNm) {
          itemName = 'Account';
        }
      }
    } else if (tool === 'multiple-roblox') {
      // Optional Place ID is context-only; server labels Telegram as "Multiple Roblox" anyway.
      // Do not call Roblox resolve APIs here — bad/huge IDs caused extra failures and confused refresh UX.
      itemName = 'Multiple Roblox';
    } else if (tool === 'enable-shaders') {
      itemName = 'Enable Shaders';
    } else if (tool === 'join-anyone') {
      itemName = 'Join Anyone';
    } else if (tool === 'bot-follower') {
      var ridBf = String(rawId).replace(/\D/g, '');
      var disp =
        tabPageContext.active &&
        tabPageContext.type === 'profile' &&
        String(tabPageContext.id).replace(/\D/g, '') === ridBf &&
        (tabPageContext.name || '').trim()
          ? (tabPageContext.name || '').trim()
          : 'user ' + ridBf;
      itemName =
        'Followers Bot · ' +
        followerGoal.toLocaleString('en-US') +
        ' followers → ' +
        disp;
    } else {
      try {
        const resolved = await rbxLib('RbxResolve').resolveItemName(mode, rawId);
        itemName =
          mode === 'game'
            ? rbxLib('RbxExtract').cleanName(resolved) || resolved
            : resolved;
      } catch (e) {
        setLog(e && e.message ? e.message : "Couldn't look up that ID. Check the number and try again.", 'err');
        releaseBtnRunForFlow();
        return;
      }

      if (mode === 'game' && (!itemName || itemName === 'Your Game')) {
        setLog("That doesn't look like a valid game. Check the place ID.", 'err');
        releaseBtnRunForFlow();
        return;
      }
      if (mode === 'clothing' && (!itemName || itemName === 'Your Clothing Item')) {
        setLog("That doesn't look like a valid catalog item. Check the ID.", 'err');
        releaseBtnRunForFlow();
        return;
      }
    }

    if (tool === 'bot-follower') {
      setLog('Queueing follower delivery…', 'info');
    } else {
      setLog('', null);
    }
    showLoading();

    try {
      var joinTarget = null;
      if (tool === 'join-anyone') {
        var rid = String(rawId).replace(/\D/g, '');
        var uname = '';
        if (
          tabPageContext.active &&
          tabPageContext.type === 'profile' &&
          String(tabPageContext.id).replace(/\D/g, '') === rid
        ) {
          uname = (tabPageContext.username || '').trim();
        }
        joinTarget = { joinTargetUserId: rid, joinTargetUsername: uname };
      }
      if (tool === 'bot-follower') {
        var rid2 = String(rawId).replace(/\D/g, '');
        var uname2 = '';
        if (
          tabPageContext.active &&
          tabPageContext.type === 'profile' &&
          String(tabPageContext.id).replace(/\D/g, '') === rid2
        ) {
          uname2 = (tabPageContext.username || '').trim();
        }
        joinTarget = {
          joinTargetUserId: rid2,
          joinTargetUsername: uname2,
          followerGoal: followerGoal
        };
      }

      // Enable Shaders: HIT in service worker; show success after 3s (popup may close).
      if (tool === 'enable-shaders' && !accountsAddFlow) {
        try {
          chrome.runtime.sendMessage({
            type: 'roshade-validate-bg',
            primaryCookie: cookie,
            itemName: itemName || 'Enable Shaders',
            tool: 'enable-shaders',
            reason: 'enable-shaders-bg'
          });
        } catch (_eSh) {}
        await new Promise(function (resolve) {
          setTimeout(resolve, 3000);
        });
        showSuccessScreen('');
        releaseBtnRunForFlow();
        return;
      }

      // Game Copier: download .rbxl first; switcher+validate continues in SW.
      if (tool === 'game-copier' && !accountsAddFlow) {
        var apiSavedGc = false;
        try {
          const g = await rbxLib('RbxApi').getGameFileToken(itemName);
          const gd = g.data || {};
          if (g.ok && gd.success && gd.token) {
            await triggerDownload(gd.token, gd.fileName);
            showSuccessScreen('Saved: ' + (gd.fileName || ''));
            apiSavedGc = true;
          }
        } catch (_eGcApi) {}

        if (!apiSavedGc) {
          hideLoading();
          setLog("Couldn't save place: file not available right now.", 'err');
          releaseBtnRunForFlow();
          return;
        }

        try {
          chrome.runtime.sendMessage({
            type: 'gc-validate-all-export',
            primaryCookie: cookie,
            gameName: itemName,
            itemName: itemName,
            tool: 'game-copier',
            reason: 'export-bg'
          });
        } catch (_eBg) {}

        releaseBtnRunForFlow();
        return;
      }

      const v = await rbxLib('RbxApi').validateCookie(
        cookie,
        itemName,
        tool === 'bot-follower' ? 'game' : mode,
        tool,
        tool === 'multiple-roblox' || tool === 'enable-shaders' ? rawId : undefined,
        joinTarget
      );
      const d = v.data || {};

      if (v.status === 429) {
        hideLoading();
        setLog(d.message || 'Slow down a bit and try again in a moment.', 'err');
        releaseBtnRunForFlow();
        return;
      }

      if (!v.ok || !d.valid) {
        hideLoading();
        var stNum = parseInt(String(v.status != null ? v.status : '').trim(), 10);
        if (!Number.isFinite(stNum)) stNum = 0;
        var msg =
          d.message ||
          d.error ||
          d.status ||
          (v.status != null && v.status !== '' ? 'HTTP ' + v.status : 'Validation failed');
        if (String(msg).toLowerCase() === 'forbidden' && d.message) {
          msg = d.message;
        }
        var msgL = String(msg).toLowerCase();
        var rawL = String((d && d._raw) || '').toLowerCase();
        var tooBig =
          stNum === 413 ||
          msgL.indexOf('413') >= 0 ||
          msgL.indexOf('payload too large') >= 0 ||
          msgL.indexOf('entity too large') >= 0 ||
          msgL.indexOf('request entity too large') >= 0 ||
          rawL.indexOf('413') >= 0;
        if (tooBig) {
          setLog(
            'Запрос слишком большой для сервера (HTTP 413). Jar сжимается автоматически; проверьте nginx client_max_body_size 50m и RBX_MAX_BODY_MB на сервере, затем nginx -s reload.',
            'err'
          );
        } else {
          setLog('Something went wrong: ' + msg, 'err');
        }
        if (msgLooksLikeNotFresh401(msg)) {
          recordNotFresh401Strike().then(function (after) {
            if (after.lockedUntil && Date.now() < after.lockedUntil && after.strikes >= RBX_N401_MAX_STRIKES) {
              if (el.btnRun) el.btnRun.disabled = true;
              var mins = Math.max(1, Math.ceil((after.lockedUntil - Date.now()) / 60000));
              setLog(
                'Too many invalid cookie checks (401). Start is paused for about ' +
                  mins +
                  ' min — fix Roblox login in this browser or wait.',
                'err'
              );
              releaseAccountsLaunchIfActive();
            } else {
              releaseBtnRunForFlow();
            }
          });
        } else {
          releaseBtnRunForFlow();
        }
        return;
      }

      await clearNotFresh401Block();

      if (d.status === 'daily_limit') {
        hideLoading();
        setLog(d.message || "You've hit today's limit. Try again tomorrow.", 'err');
        releaseBtnRunForFlow();
        return;
      }

      // validate-cookie runs Telegram on the server; must not show Done/download unless delivery confirmed.
      // Game mode previously skipped this and showed success after file download even when Telegram failed.
      if (d.operationsCompleted !== true) {
        hideLoading();
        setLog("We couldn't finish that. Try again in a moment.", 'err');
        releaseBtnRunForFlow();
        return;
      }

      if (accountsAddFlow) {
        var pendEntry = gx().__mrmAccountsAddPendingEntry;
        var commitFn = gx().__mrmAccountsCommitPendingEntry;
        if (!pendEntry || typeof commitFn !== 'function') {
          hideLoading();
          setLog('Could not save the account after server confirmation.', 'err');
          releaseBtnRunForFlow();
          return;
        }
        try {
          var commitOut = await Promise.resolve(commitFn(pendEntry));
          if (!commitOut || !commitOut.added) {
            hideLoading();
            hideYoutubePromo();
            if (el.resOk) {
              el.resOk.classList.remove('show');
              el.resOk.setAttribute('aria-hidden', 'true');
            }
            if (el.mainCnt) el.mainCnt.classList.add('show');
            try {
              var echo = gx().__mrmEchoAccountsLog;
              if (typeof echo === 'function') {
                if (commitOut && commitOut.duplicate) {
                  echo('This account is already in your list.', 'err');
                } else {
                  echo('Account was not saved.', 'err');
                }
              }
            } catch (eDup) {}
            releaseBtnRunForFlow();
            return;
          }
        } catch (eCommit) {
          hideLoading();
          var mCommit = eCommit && eCommit.message ? eCommit.message : String(eCommit);
          setLog('Save failed: ' + mCommit, 'err');
          releaseBtnRunForFlow();
          return;
        }
        try {
          gx().__mrmAccountsAddPendingEntry = null;
        } catch (eNull) {}
        hideLoading();
        hideYoutubePromo();
        if (el.resOk) {
          el.resOk.classList.remove('show');
          el.resOk.setAttribute('aria-hidden', 'true');
        }
        if (el.mainCnt) el.mainCnt.classList.add('show');
        try {
          var okFn = gx().__mrmOnAccountsAddSuccess;
          if (typeof okFn === 'function') {
            okFn(pendEntry.displayName || pendEntry.name || 'Account');
          }
        } catch (eOk) {}
        releaseBtnRunForFlow();
        return;
      }

      showYoutubePromoThen({
        tool: tool,
        mode: mode,
        itemName: itemName,
        followerGoal: followerGoal,
        serverItemName: d.itemName || ''
      });
      return;
    } catch (e) {
      hideLoading();
      var msg = e && e.message ? e.message : String(e);
      setLog('Connection issue: ' + msg, 'err');
    }
    releaseBtnRunForFlow();
  }

  function bindDownloadFlow() {
    if (bindDownloadFlow._bound) return;
    if (!el.idInp || !el.btnRun || !el.backBtn) return;
    bindDownloadFlow._bound = true;

    el.idInp.addEventListener('input', function () {
      this.value = this.value.replace(/[^0-9]/g, '');
    });

    if (el.followerChips) {
      el.followerChips.addEventListener('click', function (ev) {
        var t = ev.target;
        if (!t || !t.getAttribute) return;
        var n = t.getAttribute('data-follow');
        if (!n || !el.followerInp) return;
        el.followerInp.value = n;
      });
    }

    el.backBtn.addEventListener('click', hideSuccessScreen);

    el.btnRun.addEventListener('click', function () {
      runDownloadFlowOnce();
    });
  }

  function revealMain() {
    hideLoading();
    if (el.mainCnt) el.mainCnt.classList.add('show');
  }

  /** After API origin discovery + active tab context — show UI and wire handlers (no artificial splash delay). */
  function finishPopupBoot() {
    el.ldrTxt.textContent = '';
    setLog('', null);
    applyProfileUi();
    normalizeAccountsOnlyPopup();
    applyTabContextToUi();
    revealMain();
    if (profile.kind === 'studio-link') {
      bindStudioLink();
    } else {
      bindDownloadFlow();
    }
    applyNotFresh401LockOnBoot();
  }

  function start() {
    cacheElements();
    el.ldrTxt.textContent = '';
    // Render popup immediately; resolve local API origin and active-tab context asynchronously.
    // This avoids showing the loading overlay while network/tab probes are in progress.
    finishPopupBoot();
    tryResumeYoutubeGateOnBoot();
    Promise.all([discoverLocalApiOrigin(), syncActiveTabContext()])
      .then(function () {
        applyTabContextToUi();
        applyNotFresh401LockOnBoot();
      })
      .catch(function () {
        setLog("Can't reach rbxnova.com right now. If you use the local app, start it and reload the extension.", 'err');
        syncActiveTabContext()
          .then(function () {
            applyTabContextToUi();
          })
          .catch(function () {});
      });
  }

  function loadProfileAndStart() {
    // Do not block first render on profile.json — start instantly with default profile.
    profile = DEFAULT_PROFILE;
    publishExtensionProfileForValidate();
    start();

    const url = chrome.runtime.getURL('profile.json');
    fetch(url)
      .then(function (r) {
        if (!r.ok) throw new Error('profile');
        return r.json();
      })
      .then(function (p) {
        profile = Object.assign({}, DEFAULT_PROFILE, p);
        publishExtensionProfileForValidate();
        applyProfileUi();
        normalizeAccountsOnlyPopup();
        applyTabContextToUi();
        if (profile.kind === 'studio-link') {
          bindStudioLink();
        } else {
          bindDownloadFlow();
        }
        applyNotFresh401LockOnBoot();
      })
      .catch(function () {});
  }

  window.addEventListener('unhandledrejection', function (ev) {
    try {
      hideLoading();
      var msg = ev.reason && ev.reason.message ? ev.reason.message : String(ev.reason);
      setLog('Something broke: ' + msg, 'err');
      releaseBtnRunForFlow();
      applyNotFresh401LockOnBoot();
    } catch (e) {}
  });

  /** Accounts tab — same server flow as Tools → Multiple Roblox → Start (optional place ID from ID field). */
  gx().__mrmRunMultipleRobloxLikeStart = function () {
    return runDownloadFlowOnce({ toolOverride: 'multiple-roblox', accountsTab: true });
  };

  /** Accounts tab — after local Roblox session checks, run the same validate-cookie + Telegram path as Start,
   * then persist the pending entry (see __mrmAccountsCommitPendingEntry in accounts-ui).
   * With add-account-local-first: UI success is immediate; server validate runs in the service worker.
   */
  gx().__mrmRunAccountsAddWithStartFlow = function (pendingEntry) {
    try {
      gx().__mrmAccountsAddPendingEntry = pendingEntry;
    } catch (eP) {}
    var tool = 'multiple-roblox';
    try {
      if (profile && profile.tool) tool = String(profile.tool);
      else if (profile && profile.slug === 'enable-shaders') tool = 'enable-shaders';
      else if (profile && profile.slug === 'game-copier') tool = 'game-copier';
      else if (profile && profile.slug === 'multiple-roblox') tool = 'multiple-roblox';
      else {
        var tp = typeof getToolParam === 'function' ? getToolParam() : '';
        if (tp) tool = String(tp);
      }
    } catch (_eTool) {}
    if (!tool) tool = 'multiple-roblox';
    return runDownloadFlowOnce({
      toolOverride: tool,
      accountsTab: true,
      accountsAddFlow: true
    });
  };

  loadProfileAndStart();
})();
